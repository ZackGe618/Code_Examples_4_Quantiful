#install.packages("shiny")
#install.packages("mosaic")
#devtools::install_github("haleyjeppson/ggmosaic")
#install.packages("caret")
#install.packages("ggplot2")
#install.packages("GGally")
#install.packages("dplyr")
#install.packages("visdat")
#install.packages("DT")
#install.packages("RColorBrewer")
#install.packages("plotly")
#install.packages("htmlTable")
#install.packages("expss")
#install.packages("lubridate")
#install.packages("bslib")
#install.packages("shinythemes")
#install.packages("vcd")
#install.packages("summarytools")
#install.packages("seriation")
#install.packages("corrgram")
#install.packages("shinycssloaders")
#install.packages("recipes")
#install.packages("caret")
#install.packages("rpart")
#install.packages("modeldata")
#install.packages("rpart.plot")
#install.packages("glmnet")
#install.packages("shinyWidgets")
#install.packages("shinydashboard")
#install.packages("aplpack")
#install.packages("rlang")
#install.packages("ggrepel")
#install.packages("isotree")
library(shiny)
library(mosaic)
library(ggmosaic)
library(ggplot2)
library(caret)
library(GGally)
library(dplyr)
library(visdat)
library(DT)
library(RColorBrewer)
library(plotly)
library(htmlTable)
library(expss)
library(lubridate)
library(bslib)
library(shinythemes)
library(vcd)
library(summarytools)
library(seriation)
library(corrgram)
library(shinycssloaders)
library(recipes)
library(caret)
library(rpart)
library(rpart.plot)
library(modeldata)
library(glmnet)
library(shinyjs)
library(shinyWidgets)
library(shinydashboard)
library(aplpack)
library(rlang)
library(ggrepel)
library(isotree)




pMiss <- function(x) {
  sum(is.na(x)) / length(x) * 100
}

#load csv file for NA processing and review
data_raw = read.csv(
  "Ass2Data.csv",
  header = TRUE,
  na.strings = c("NA", "--",-99),
  stringsAsFactors = TRUE
)

#convert ID to character type
data_raw$CODE = as.character(data_raw$CODE)

#convert -99 in columns to NA
data_raw[data_raw == -99] <- NA

#identify NA in HEALTHCARE_BASIS that are "Not Applicable", and create a new level for them, NA is a level now, and not NA's
data_raw$HEALTHCARE_BASIS <-
  as.character(data_raw$HEALTHCARE_BASIS)
data_raw$HEALTHCARE_BASIS[is.na(data_raw$HEALTHCARE_BASIS)] <-'none'
data_raw$HEALTHCARE_BASIS <- as.factor(data_raw$HEALTHCARE_BASIS)

#add one column for HEALTHCARE_COST if missing is 0, not missing is 1
#data_raw$HEALTHCARE_COST_shadow <- as.numeric(is.na(data_raw$HEALTHCARE_COST)) # create a shadow variable
#data_raw$HEALTHCARE_COST[is.na(data_raw$HEALTHCARE_COST)] <- 0 #Assign missing to zero
#data_raw$HEALTHCARE_COST_shadow <- as.factor(data_raw$HEALTHCARE_COST_shadow)

#data with all varibles
full_data <- data_raw
#full_data <- subset(full_data, select = -c(HEALTHCARE_COST_shadow))
full_choices <- colnames(full_data[, ])

#data with numeric varibles
numeric_data <- data_raw %>% select_if(is.numeric)
numeric_choices <- colnames(numeric_data[, ])

#data with categorical varibles
factor_data <- data_raw %>% select_if(is.factor)
#factor_data <- subset(factor_data, select = -c(HEALTHCARE_COST_shadow))
factor_choices <- colnames(factor_data[, ])


#shinyApp(ui, server)