# Define server logic
server <- function(input, output, session) {
  #Sys.sleep(time = 2) introduce 2 seconds delay in the execution of the "renderPlot()"
  
  react <-
    reactiveValues(
      cleanData1 = NULL,
      cleanData2 = NULL,
      train = NULL,
      full_choices = NULL,
      numeric_data = NULL,
      numeric_choices = NULL,
      factor_data = NULL,
      factor_choices = NULL,
      test = NULL,
      test_pre = NULL,
      test_prerecipe = NULL,
      model = NULL,
      predictions = NULL,
      test_with_pred = NULL,
      train_with_pred = NULL,
      rec_imp_full = NULL,
      rec_imp_train = NULL,
      rec_imp_test = NULL,
      data_final = NULL
    )
  
  onSessionEnded(function() {
    stopApp()
  })
  
  
  
  getData <- reactive({
    data_raw <- data_raw
    if (input$Transfer_for_Healthcare_cost != "Not Avaliable - No Shadown Column to be created   ") {
      #add one column for HEALTHCARE_COST if missing is 0, not missing is 1
      data_raw$HEALTHCARE_COST_shadow <-
        as.numeric(is.na(data_raw$HEALTHCARE_COST)) # create a shadow variable
      data_raw$HEALTHCARE_COST[is.na(data_raw$HEALTHCARE_COST)] <-
        0 #Assign missing to zero
      data_raw$HEALTHCARE_COST_shadow <-
        as.factor(data_raw$HEALTHCARE_COST_shadow)
    } else{
      data_raw <- data_raw
    }
    
    if(input$VAX_RATE_Transform){
        data_raw$VAX_RATE[data_raw$VAX_RATE == 15] <- NA
    }
    
    if(input$HEALTHCARE_free_Transform){
      data_raw$HEALTHCARE_COST[data_raw$HEALTHCARE_BASIS == "FREE"] <- 0
      
    }
    
    data_raw
  })
  
  # Structure_raw output
  output$glimpse_raw <- renderPrint({
    #disselect ID column
    str(getData())
  })
  
  # summary_raw output
  output$summary_raw <- renderPrint({
    summary(getData())
  })
  
  # Summary table with value visualization for each variable - dfSummary() funciton
  output$summary_table <- renderUI({
   print(dfSummary(getData()), method = "render")
  })
  
  #create data table
  output$Ass2Data <- DT::renderDataTable({
    # create data table
    DT::datatable(
      data = data_raw,
      options = list(
        paging = TRUE,
        pageLength = 20,
        pagingType = "full_numbers"
      )
    )
  })
  
  # Processed data overview
  # glimpse_processed_data output
  #output$glimpse_processed_data <- renderPrint({
  #  #disselect ID column
  #  str(react$cleanData2)
  #})
  #
  ## summary_processed_data output
  #output$summary_processed_data <- renderPrint({
  #  summary(react$cleanData2)
  #})
  
  #Original: observe select_all_vars_boxplot_raw to modify if all variables should be selected:
  observeEvent(input$select_all_vars_boxplot_raw, {
    if (input$select_all_vars_boxplot_raw) {
      updateSelectInput(session,
                        "VariablesBox_raw",
                        choices = numeric_choices,
                        selected = numeric_choices)
    }
  })
  
  observeEvent(input$VariablesBox_raw, {
    if (length(input$VariablesBox_raw) != length(numeric_choices)) {
      updateCheckboxInput(session, "select_all_vars_boxplot_raw", value = FALSE)
    }
  })
  
  #Original: For Boxplot - Original data
  output$Boxplot_raw <- renderPlot({
    #using the original data
    data <- numeric_data
    req(data)
    criterion <- input$boxplot_IQR_raw
    cols <- input$VariablesBox_raw # choose the continuous columns
    numData <-
      scale(data[, cols],
            center = input$center_Box_raw,
            scale = input$scale_Box_raw)
    car::Boxplot(
      numData,
      range = criterion,
      col = c(
        "palegreen",
                   "paleturquoise1",
                   "palevioletred1",
                   "rosybrown1",
                   "khaki1",
                   "plum2",
                   "slategray1",
                   "aliceblue"
      ),
      main = "BoxPlot for Raw Data"
    )
  })
  
  #Original: For Boxplot outliers - Original data
  output$Boxplot_raw_result <- renderPrint({
    # Load the data and required variables
    data <- numeric_data
    criterion <- input$boxplot_IQR_raw
    cols <- input$VariablesBox_raw # Choose the continuous columns
    # Check for data presence
    req(data)
    # Set plot margins
    par(mar = c(3, 3, 2, 2))
    # Print column names and boxplot outputs
    if (input$show_Outliers_BoxPlot_raw) {
      cat("Observations to be investigated:\n")
      for (col in cols) {
        cat("[")
        # Calculate scaled data and create boxplot
        numData <-
          scale(data[, col],
                center = input$center_Box_raw,
                scale = input$scale_Box_raw)
        boxplot <-
          car::Boxplot(numData, range = criterion, col = "lightblue")
        cat(col, ": ", "\n")
        for (i in boxplot) {
          cat(i, '\n')
        }
        cat("].")
      }
    }
  })
  
  #Reactive: For Boxplot - reactive data
  # Observer that updates the VariablesBox_rec widget based on the cleanData2
  observe({
    data <- react$cleanData2
    req(data)
    updateSelectizeInput(
      session,
      "VariablesBox_rec",
      choices = react$numeric_choices,
      selected = react$numeric_choices
    )
  })
  
  #Reactive: observe select_all_vars_boxplot_rec to modify if all variables should be selected:
  observeEvent(input$select_all_vars_boxplot_rec, {
    if (input$select_all_vars_boxplot_rec) {
      updateSelectizeInput(
        session,
        "VariablesBox_rec",
        choices = react$numeric_choices,
        selected = react$numeric_choices
      )
    }
  })
  
  observeEvent(input$VariablesBox_rec, {
    if (length(input$VariablesBox_rec) != length(react$numeric_choices)) {
      updateCheckboxInput(session, "select_all_vars_boxplot_rec", value = FALSE)
    } else {
      updateCheckboxInput(session, "select_all_vars_boxplot_rec", value = TRUE)
    }
  })
  
  #Reactive: For Boxplot - reactive data
  output$Boxplot_rec <- renderPlot({
    #using the original data
    data <- react$numeric_data
    req(data)
    criterion <- input$boxplot_IQR_rec
    cols <- input$VariablesBox_rec # choose the continuous columns
    numData <-
      scale(data[, cols],
            center = input$center_Box_rec,
            scale = input$scale_Box_rec)
    car::Boxplot(
      numData,
      range = criterion,
      col = c(
        "palegreen",
                   "paleturquoise1",
                   "palevioletred1",
                   "rosybrown1",
                   "khaki1",
                   "plum2",
                   "slategray1",
                   "aliceblue"
      ),
      main = paste(
        "BoxPlot for Processed Data \n",
        "Thresholds VarMiss:",
        input$VarThreshold,
        "%, ",
        "ObsMiss:",
        input$ObsThreshold,
        "%"
      )
    )
    
  })
  
  #Reactive: For Boxplot outliers - Reactive data
  output$Boxplot_rec_result <- renderPrint({
    # Load the data and required variables
    data <- react$numeric_data
    req(data)
    criterion <- input$boxplot_IQR_rec
    cols <- input$VariablesBox_rec # Choose the continuous columns
    # Set plot margins
    par(mar = c(3, 3, 2, 2))
    # Print column names and boxplot outputs
    if (input$show_Outliers_BoxPlot_rec) {
      cat("Observations to be investigated:\n")
      for (col in cols) {
        cat("[")
        # Calculate scaled data and create boxplot
        numData <-
          scale(data[, col],
                center = input$center_Box_rec,
                scale = input$scale_Box_rec)
        boxplot <-
          car::Boxplot(numData, range = criterion, col = "lightblue")
        cat(col, ": ", "\n")
        for (i in boxplot) {
          cat(i, '\n')
        }
        cat("].")
      }
    }
  })
  
  #Original: observe select_all_vars_Rising_raw to modify if all variables should be selected:
  observeEvent(input$select_all_vars_Rising_raw, {
    if (input$select_all_vars_Rising_raw) {
      updateSelectInput(session,
                        "VariablesRising_raw",
                        choices = numeric_choices,
                        selected = numeric_choices)
    }
  })
  
  observeEvent(input$VariablesRising_raw, {
    if (length(input$VariablesRising_raw) != length(numeric_choices)) {
      updateCheckboxInput(session, "select_all_vars_Rising_raw", value = FALSE)
    }
  })
  
  #Original: For Rising Value Plot - Original data
  output$rising_value_chart_raw <- renderPlot({
    data <- numeric_data
    req(data)
    data = subset(data, select = input$VariablesRising_raw)
    cols <- input$VariablesRising_raw
    for (col in 1:ncol(data)) {
      data[, col] <-
        data[order(data[, col]), col] #sort each column in ascending order
    }
    d <-
      scale(
        x = data,
        center = input$center_RV_raw,
        scale = input$scale_RV_raw
      )
    mypalette <- rainbow(ncol(d))
    matplot(
      x = seq(1, 100, length.out = nrow(d)),
      y = d,
      type = "l",
      xlab = "Percentile",
      ylab = "Values",
      lty = 1,
      lwd = 1,
      col = mypalette,
      main = "Rising value chart for Raw Data"
    )
    if (input$show_legend_RV_raw) {
      legend(
        legend = colnames(d),
        x = "topleft",
        y = "top",
        lty = 1,
        lwd = 1,
        col = mypalette,
        ncol = round(ncol(d) ^ 0.3)
      )
    }
  })
  
  #Reactive: For Rising Value Plot - reactive data
  # Observer that updates the VariablesRising_rec widget based on the cleanData2
  observe({
    data <- react$numeric_data
    req(data)
    updateSelectizeInput(
      session,
      "VariablesRising_rec",
      choices = react$numeric_choices,
      selected = react$numeric_choices
    )
  })
  
  #Reactive: observe select_all_vars_Rising_rec to modify if all variables should be selected:
  observeEvent(input$select_all_vars_Rising_rec, {
    if (input$select_all_vars_Rising_rec) {
      updateSelectInput(
        session,
        "VariablesRising_rec",
        choices = react$numeric_choices,
        selected = react$numeric_choices
      )
    }
  })
  
  observeEvent(input$VariablesRising_rec, {
    if (length(input$VariablesRising_rec) != length(react$numeric_choices)) {
      updateCheckboxInput(session, "select_all_vars_Rising_rec", value = FALSE)
    } else {
      updateCheckboxInput(session, "select_all_vars_Rising_rec", value = TRUE)
    }
  })
  
  #Reactive: For Rising Value Plot - Reactive data
  output$rising_value_chart_rec <- renderPlot({
    data <- react$numeric_data
    req(data)
    data = subset(data, select = input$VariablesRising_rec)
    cols <- input$VariablesRising_rec
    for (col in 1:ncol(data)) {
      data[, col] <-
        data[order(data[, col]), col] #sort each column in ascending order
    }
    d <-
      scale(
        x = data,
        center = input$center_RV_rec,
        scale = input$scale_RV_rec
      )
    mypalette <- rainbow(ncol(d))
    
    matplot(
      x = seq(1, 100, length.out = nrow(d)),
      y = d,
      type = "l",
      xlab = "Percentile",
      ylab = "Values",
      lty = 1,
      lwd = 1,
      col = mypalette,
      main = paste(
        "Rising value chart for Processed Data \n",
        "Thresholds VarMiss:",
        input$VarThreshold,
        "%, ",
        "ObsMiss:",
        input$ObsThreshold,
        "%"
      )
    )
    if (input$show_legend_RV_rec) {
      legend(
        legend = colnames(d),
        x = "topleft",
        y = "top",
        lty = 1,
        lwd = 1,
        col = mypalette,
        ncol = round(ncol(d) ^ 0.3)
      )
    }
  })
  
  
  #Original: plot histogram chart
  output$histogram_chart_raw <- renderPlotly({
    data <- numeric_data
    req(data)
    hist_var_selected = input$Variables_hist_raw
    p <-
      ggplot2::ggplot(data = data, mapping = aes(x = !!sym(hist_var_selected))) +
      geom_histogram(bins = input$hist_bins_raw) +
      labs(
        title = paste("Histogram of ", hist_var_selected, " (from Raw Data)"),
        xlab = paste("The range of", hist_var_selected)
      )
    ggplotly(p)
  })
  
  #Reactive: For Histogram Plot - reactive data
  # Observer that updates the Variables_hist_rec widget based on the cleanData2
  observe({
    data <- react$numeric_data
    req(data)
    updateSelectizeInput(
      session,
      "Variables_hist_rec",
      choices = react$numeric_choices,
      selected = react$numeric_choices
    )
  })
  
  #Reactive: plot histogram chart
  output$histogram_chart_rec <- renderPlotly({
    data <- react$numeric_data
    req(data)
    hist_var_selected = input$Variables_hist_rec
    p <-
      ggplot2::ggplot(data = data, mapping = aes(x = !!sym(hist_var_selected))) +
      geom_histogram(bins = input$hist_bins_rec) +
      labs(
        title = paste(
          "Histogram of ",
          hist_var_selected,
          " (from Processed Data)   ",
          "Thresholds VarMiss:",
          input$VarThreshold,
          "%, ",
          "ObsMiss:",
          input$ObsThreshold,
          "%"
        ),
        xlab = paste("The range of", hist_var_selected)
      )
    ggplotly(p)
  })
  
  #Original: observe select_all_vars_matplot_raw to modify if all variables should be selected:
  observeEvent(input$select_all_vars_matplot_raw, {
    if (input$select_all_vars_matplot_raw) {
      updateSelectInput(session,
                        "Variables_Matplot_raw",
                        choices = numeric_choices,
                        selected = numeric_choices)
    }
  })
  observeEvent(input$Variables_Matplot_raw, {
    if (length(input$Variables_Matplot_raw) != length(numeric_choices)) {
      updateCheckboxInput(session, "select_all_vars_matplot_raw", value = FALSE)
    }
  })
  
  #Original:plot homogeneity chart
  output$homogeneity_chart_raw <- renderPlot({
    data <- numeric_data
    # choose the numeric columns
    cols <- input$Variables_Matplot_raw
    data_use <-
      scale(data[, cols],
            center = input$center_Homo_raw,
            scale = input$scale_Homo_raw)
    matplot(
      data_use,
      type = "l",
      col = rainbow(ncol(data_use)),
      xlab = "Observations in sequence",
      ylab = "Value",
      main = "Matplot of Raw Data"
    )
  })
  
  #Reactive: For Matplot  - reactive data
  # Observer that updates the Variables_Matplot_rec widget based on the cleanData2
  observe({
    data <- react$numeric_choices
    req(data)
    updateSelectizeInput(
      session,
      "Variables_Matplot_rec",
      choices = react$numeric_choices,
      selected = react$numeric_choices
    )
  })
  
  #Reactive: observe select_all_vars_matplot_rec to modify if all variables should be selected:
  observeEvent(input$select_all_vars_matplot_rec, {
    if (input$select_all_vars_matplot_rec) {
      updateSelectInput(
        session,
        "Variables_Matplot_rec",
        choices = react$numeric_choices,
        selected = react$numeric_choices
      )
    }
  })
  
  observeEvent(input$Variables_Matplot_rec, {
    if (length(input$Variables_Matplot_rec) != length(react$numeric_choices)) {
      updateCheckboxInput(session, "select_all_vars_matplot_rec", value = FALSE)
    } else {
      updateCheckboxInput(session, "select_all_vars_matplot_rec", value = TRUE)
    }
  })
  
  #Reactive:plot homogeneity chart
  output$homogeneity_chart_rec <- renderPlot({
    data <- react$numeric_data
    # choose the numeric columns
    cols <- input$Variables_Matplot_rec
    data_use <-
      scale(data[, cols],
            center = input$center_Homo_rec,
            scale = input$scale_Homo_rec)
    matplot(
      data_use,
      type = "l",
      col = rainbow(ncol(data_use)),
      xlab = "Observations in sequence",
      ylab = "Value",
      main = paste(
        "Matplot of Processed Data \n",
        "Thresholds VarMiss:",
        input$VarThreshold,
        "%, ",
        "ObsMiss:",
        input$ObsThreshold,
        "%"
      )
    )
  })
  
  #Original: Plot output of Mosaic
  output$Mosaic_raw <- renderPlot({
    data <- factor_data
    formula <-
      as.formula(paste("~", paste(
        input$Variables_Mosaic_raw, collapse = " + "
      )))
    vcd::mosaic(
      formula,
      data = data,
      main = "Mosaic Plot for Discrete Variable (from Raw Data)",
      shade = TRUE,
      legend = TRUE
    )
  })
  
  #Reactive: For Rising Value Plot - reactive data
  # Observer that updates the Variables_Mosaic_rec widget based on the cleanData2
  observe({
    data <- react$factor_choices
    req(data)
    updateSelectizeInput(
      session,
      "Variables_Mosaic_rec",
      choices = react$factor_choices,
      selected = react$factor_choices
    )
  })
  
  #Reactive: Plot output of Mosaic
  output$Mosaic_rec <- renderPlot({
    data <- react$factor_data
    formula <-
      as.formula(paste("~", paste(
        input$Variables_Mosaic_rec, collapse = " + "
      )))
    vcd::mosaic(
      formula,
      data = data,
      main = paste(
        "Mosaic Plot for Discrete Variable (from Processed Data) ",
        "Thresholds VarMiss:",
        input$VarThreshold,
        "%, ",
        "ObsMiss:",
        input$ObsThreshold,
        "%"
      ),
      shade = TRUE,
      legend = TRUE
    )
    
  })
  
  #Original: Update the input whenever select_all_vars is checked
  observeEvent(input$select_all_vars_cor_raw, {
    if (input$select_all_vars_cor_raw) {
      updateSelectInput(session,
                        "Variables_cor_raw",
                        choices = numeric_choices,
                        selected = numeric_choices)
    }
  })
  observeEvent(input$Variables_cor_raw, {
    if (length(input$Variables_cor_raw) != length(numeric_choices)) {
      updateCheckboxInput(session, "select_all_vars_cor_raw", value = FALSE)
    }  else {
      updateCheckboxInput(session, "select_all_vars_cor_raw", value = TRUE)
    }
  })
  
  #Original: Plot output of Corrgram
  output$AutoCorr_raw <- renderPlot({
    data <- numeric_data
    # select data based on input$Variables_cor_raw
    data_df_VC = subset(data, select = input$Variables_cor_raw)
    #disselect NA values
    data_df_VC_noNA <- na.omit(data_df_VC)
    #Plot Correlation Chart
    corrgram::corrgram(
      data_df_VC_noNA,
      order = input$Order_cor_raw,
      abs = input$abs_raw,
      upper.panel = panel.cor,
      cor.method = input$cor_method_sel_raw,
      main = "Correlation Chart for Raw Data"
    )
  })
  
  #Reactive: For Correlation  - reactive data
  # Observer that updates the Variables_cor_raw widget based on the cleanData2
  observe({
    data <- react$numeric_choices
    req(data)
    updateSelectizeInput(
      session,
      "Variables_cor_rec",
      choices = react$numeric_choices,
      selected = react$numeric_choices
    )
  })
  
  #Reactive: Update the input whenever select_all_vars is checked
  observeEvent(input$select_all_vars_cor_rec, {
    if (input$select_all_vars_cor_rec) {
      updateSelectInput(
        session,
        "Variables_cor_rec",
        choices = react$numeric_choices,
        selected = react$numeric_choices
      )
    }
  })
  observeEvent(input$Variables_cor_rec, {
    if (length(input$Variables_cor_rec) != length(react$numeric_choices)) {
      updateCheckboxInput(session, "select_all_vars_cor_rec", value = FALSE)
    }  else {
      updateCheckboxInput(session, "select_all_vars_cor_rec", value = TRUE)
    }
  })
  
  #Reactive: Plot output of Corrgram
  output$AutoCorr_rec <- renderPlot({
    data <- react$numeric_data
    # select data based on input$Variables_cor_rec
    req(data)
    if (ncol(data) >= 2) {
      data_df_VC = subset(data, select = input$Variables_cor_rec)
      #disselect NA values
      data_df_VC_noNA <- na.omit(data_df_VC)
      #Plot Correlation Chart
      corrgram::corrgram(
        data_df_VC_noNA,
        order = input$Order_cor_rec,
        abs = input$abs_rec,
        upper.panel = panel.cor,
        cor.method = input$cor_method_sel_rec,
        main = paste(
          "Correlation Chart for Processed Data \n",
          "Thresholds VarMiss:",
          input$VarThreshold,
          "%, ",
          "ObsMiss:",
          input$ObsThreshold,
          "%"
        )
      )
    } else {
      #show modal message
      showModal(
        modalDialog(
          title = "Invalid Correlation Plot for Processed Data (Second Plot)",
          "The minimum value for the number of numeric variables in corrgram::corrgram() is 2. However, after removing missing values from the dataset based on the specified threshold, the number of remaining numeric variables is less than two, which is insufficient for second plot. But this does not have any impact on the first Plot.",
          easyClose = TRUE,
          footer = NULL,
          size = "m",
          tags$head(
            tags$style(".modal-dialog { margin-top: 40% !important; }")
          )
        )
      )
      updateCheckboxInput(session, "select_all_vars_cor_rec", value = FALSE)
      updateSelectInput(session, "cor_method_sel_rec", selected = "")
      updateSelectInput(session, "Order_cor_rec", selected = "")
      updateCheckboxInput(session, "abs_rec", value = FALSE)
    }
  })
  
  
  #Original: Plot output of ggpairs
  output$Ggpairs_raw <- renderPlot({
    #disselect ID column
    data <- full_data
    data <- na.omit(data)
    # select data based on input$VariableB
    neededVars <-
      c(input$Variable_gg_raw, input$color_sel_ggpairs_raw)
    data_df_VB <- data[, neededVars]
    # color selection based on input$color_sel_ggpairs_raw
    color_sel = input$color_sel_ggpairs_raw
    #plot ggpairs, note the selection input returns quoted result, but for color argument, it needs unquoted value
    GGally::ggpairs(
      data = data_df_VB,
      mapping = aes(colour = !!sym(input$color_sel_ggpairs_raw)),
      title = paste("Pairs of Ass2Data colored by", color_sel, "for Raw Data"),
      progress = TRUE
    )
  })
  
  #Reactive: For ggpairs  - reactive data
  # Observer that updates the Variables_cor_raw widget based on the cleanData2
  observe({
    data <- react$numeric_choices
    req(data)
    updateSelectizeInput(
      session,
      "Variable_gg_rec",
      choices = react$numeric_choices,
      selected = react$numeric_choices
    )
    updateSelectInput(session,
                      "color_sel_ggpairs_rec",
                      choices = react$factor_choices)
  })
  
  #Reactive: Plot output of ggpairs
  output$Ggpairs_rec <- renderPlot({
    #disselect ID column
    data <- react$cleanData2
    req(data)
    data <- na.omit(data)
    # select data based on input$VariableB
    neededVars <-
      c(input$Variable_gg_rec, input$color_sel_ggpairs_rec)
    data_df_VB <- data[, neededVars]
    # color selection based on input$color_sel_ggpairs_raw
    color_sel = input$color_sel_ggpairs_rec
    #plot ggpairs, note the selection input returns quoted result, but for color argument, it needs unquoted value
    GGally::ggpairs(
      data = data_df_VB,
      mapping = aes(colour = !!sym(input$color_sel_ggpairs_rec)),
      title = paste(
        "Pairs of Ass2Data colored by",
        color_sel,
        "for Processed Data        ",
        "Thresholds VarMiss:",
        input$VarThreshold,
        "%, ",
        "ObsMiss:",
        input$ObsThreshold,
        "%"
      ),
      progress = TRUE
    )
    
  })
  
  #Original: Update the input whenever select_all_vars is checked
  observeEvent(input$select_all_vars_vis_raw, {
    if (input$select_all_vars_vis_raw) {
      updateSelectInput(session,
                        "Variables_missing_raw",
                        choices = full_choices,
                        selected = full_choices)
    }
  })
  
  observeEvent(input$Variables_missing_raw, {
    if (length(input$Variables_missing_raw) != length(full_choices)) {
      updateCheckboxInput(session, "select_all_vars_vis_raw", value = FALSE)
    } else{
      updateCheckboxInput(session, "select_all_vars_vis_raw", value = TRUE)
    }
  })
  
  #Original: Plot Missing data Visualization
  output$vis_dat_raw <- renderPlot({
    # convert data into DataFrame
    data <- full_data
    # select data based on input$VariableD
    data_use_vis_dat = subset(data, select = input$Variables_missing_raw)
    # plot Missing Value Chart by vis_dat
    vis_dat(data_use_vis_dat) +
      ggtitle("Missing Data for all variables by variable type (Raw Data)")
  })
  
  #Reactive: For Missing1  - reactive data
  # Observer that updates the Variables_cor_raw widget based on the cleanData2
  observe({
    data <- react$full_choices
    req(data)
    updateSelectizeInput(
      session,
      "Variables_missing_rec",
      choices = react$full_choices,
      selected = react$full_choices
    )
  })
  
  #Reactive: Update the input whenever select_all_vars is checked
  observeEvent(input$select_all_vars_vis_rec, {
    if (input$select_all_vars_vis_rec) {
      updateSelectizeInput(
        session,
        "Variables_missing_rec",
        choices = react$full_choices,
        selected = react$full_choices
      )
    }
  })
  
  observeEvent(input$Variables_missing_rec, {
    if (length(input$Variables_missing_rec) != length(react$full_choices)) {
      updateCheckboxInput(session, "select_all_vars_vis_rec", value = FALSE)
    } else{
      updateCheckboxInput(session, "select_all_vars_vis_rec", value = TRUE)
    }
  })
  
  #Reactive: Plot Missing data Visualization
  output$vis_dat_rec <- renderPlot({
    # convert data into DataFrame
    data <- react$cleanData2
    # select data based on input$VariableD
    data_use_vis_dat = subset(data, select = input$Variables_missing_rec)
    # plot Missing Value Chart by vis_dat
    vis_dat(data_use_vis_dat) +
      #ggtitle("Missing Data for all variables by variable type (Processed Data)")+
      labs(
        title = paste(
          "Missing Data for all variables by variable type (Processed Data) \n",
          "Thresholds VarMiss:",
          input$VarThreshold,
          "%, ",
          "ObsMiss:",
          input$ObsThreshold,
          "%"
        )
      )
  })
  
  #Original: Update the input whenever select_all_vars is checked
  observeEvent(input$select_all_vars_vis_missing_raw, {
    if (input$select_all_vars_vis_missing_raw) {
      updateSelectInput(session,
                        "Variables_missing2_raw",
                        choices = full_choices,
                        selected = full_choices)
    }
  })
  
  observeEvent(input$Variables_missing2_raw, {
    if (length(input$Variables_missing2_raw) != length(full_choices)) {
      updateCheckboxInput(session, "select_all_vars_vis_missing_raw", value = FALSE)
    } else{
      updateCheckboxInput(session, "select_all_vars_vis_missing_raw", value = TRUE)
    }
  })
  
  #Original: Plot Missing data Visualization
  output$vis_miss_raw <- renderPlot({
    # convert data into DataFrame
    data <- full_data
    
    # select data based on input$VariableD
    data_use_vis_miss = subset(data, select = input$Variables_missing2_raw)
    # plot Missing Value Chart by vis_miss
    vis_miss(data_use_vis_miss, cluster = input$cluster_raw) +
      labs(title = "Percentage of Missing Value for Raw Data") +
      theme(legend.position = "right")
  })
  
  #Reactive: For Missing2  - reactive data
  # Observer that updates the Variables_cor_raw widget based on the cleanData2
  observe({
    data <- react$full_choices
    req(data)
    updateSelectizeInput(
      session,
      "Variables_missing2_rec",
      choices = react$full_choices,
      selected = react$full_choices
    )
  })
  
  #Reactive: Update the input whenever select_all_vars is checked
  observeEvent(input$select_all_vars_vis_missing_rec, {
    if (input$select_all_vars_vis_missing_rec) {
      updateSelectizeInput(
        session,
        "Variables_missing2_rec",
        choices = react$full_choices,
        selected = react$full_choices
      )
    }
  })
  
  observeEvent(input$Variables_missing2_rec, {
    if (length(input$Variables_missing2_rec) == length(react$full_choices)) {
      updateCheckboxInput(session, "select_all_vars_vis_missing_rec", value = TRUE)
    } else{
      updateCheckboxInput(session, "select_all_vars_vis_missing_rec", value = FALSE)
    }
  })
  
  #Reactive: Plot Missing2 data Visualization
  output$vis_miss_rec <- renderPlot({
    # convert data into DataFrame
    data <- react$cleanData2
    
    # select data based on input$VariableD
    data_use_vis_miss = subset(data, select = input$Variables_missing2_rec)
    # plot Missing Value Chart by vis_miss
    vis_miss(data_use_vis_miss, cluster = input$cluster_rec) +
      #labs(title = "Percentage of Missing Value for Processed Data")+
      theme(legend.position = "right") +
      labs(
        title = paste(
          "Percentage of Missing Value for Processed Data",
          "Thresholds VarMiss:",
          input$VarThreshold,
          "%, ",
          "ObsMiss:",
          input$ObsThreshold,
          "%"
        )
      )
  })
  
  #Original: Plot output of Variable Importance
  output$Variable_Impor_raw <- renderPlot({
    data <- full_data
    #disselect ID column
    data <- select(data,-c(CODE))
    data_df_no_Vdate.train <- filter(data, OBS_TYPE == "Train")
    data_df_no_Vdate.test <- filter(data, OBS_TYPE == "Test")
    
    modass1 <-
      caret::train(
        form = DEATH_RATE ~ .,
        data = data_df_no_Vdate.train,
        method = input$method_sel_raw,
        na.action = na.omit
      )
    plot(
      caret::varImp(modass1),
      top = input$top_display_raw,
      main = paste("Variable Importance Plot - Top", input$top_display_raw)
    )
  })
  
  #Reactive: Plot output of Variable Importance
  output$Variable_Impor_rec <- renderPlot({
    data <- react$cleanData2
    req(data)
    data <- select(data,-c(CODE))
    #disselect ID and Date column
    data_df_no_Vdate.train <- filter(data, OBS_TYPE == "Train")
    data_df_no_Vdate.test <- filter(data, OBS_TYPE == "Test")
    
    modass2 <-
      caret::train(
        form = DEATH_RATE ~ .,
        data = data_df_no_Vdate.train,
        method = input$method_sel_rec,
        na.action = na.omit
      )
    plot(
      caret::varImp(modass2),
      top = input$top_display_rec,
      main = paste(
        "Variable Importance Plot - Top",
        input$top_display_rec,
        "\n",
        "Thresholds VarMiss:",
        input$VarThreshold,
        "%, ",
        "ObsMiss:",
        input$ObsThreshold,
        "%"
      )
    )
    
  })
  
  #original:for Pattern Plot - original data
  output$Pattern_raw <- renderPlot({
    #using the original data
    data <- getData()
    req(data)
    #plot
    naniar::gg_miss_upset(data = data, nsets = input$nsets_raw)
  })
  
  # Observer that updates the numericInput widget based on the cleanData2
  observe({
    data <- react$cleanData2
    req(data)
    if(sum(colSums(is.na(data)) > 0) >= input$nsets_raw){
    updateNumericInput(session, "nsets_rec", value = input$nsets_raw)
    }else {
      updateNumericInput(session, "nsets_rec", value = sum(colSums(is.na(data)) > 0))
      }
  })
  
  #Reactive:for pattern plot - cleanData2
  output$Pattern_rec <- renderPlot({
    #using the reactive data
    data <- react$cleanData2
    req(data)
    #since this plot needs 2 variables at least, we need to check if it has 2 or more
    missing_column_counts <- sum(colSums(is.na(data)) > 0)
    if (any(missing_column_counts >= 2)) {
      #plot
      naniar::gg_miss_upset(data = data, nsets = input$nsets_rec)
    } else {
      #show modal message
      showModal(
        modalDialog(
          title = "Invalid Pattern Plot for Processed Data (Second Plot)",
          "The minimum value for nsets in gg_miss_upset() is 2. However, after removing missing values from the dataset based on the specified threshold, the number of remaining variables with missing values is less than two, which is insufficient for second plot. But this does not have any impact on the first Plot.",
          easyClose = TRUE,
          footer = NULL,
          size = "m",
          tags$head(
            tags$style(".modal-dialog { margin-top: 40% !important; }")
          )
        )
      )
    }
  })
  
  
  
  
  
  
  
  #Removing Missing Values:
  
  output$selected_result <- renderText({
    data <- react$cleanData2
    req(data)
    paste("Cleaned data: observations are ",
          dim(data)[1],
          " & ",
          "Variables are ",
          dim(data)[2],
          ".")
    #paste("You selected", )
  })
  
  # summary_raw output
  output$summary_processed_1 <- renderPrint({
    summary(getData())
  })
  
  # Structure_raw output
  output$glimpse_processed <- renderPrint({
    #disselect ID column
    str(react$cleanData2)
  })
  
  # summary_raw output
  output$summary_processed <- renderPrint({
    summary(react$cleanData2)
  })
  
  ## Summary table with value visualization for each variable - dfSummary() funciton
  #output$summary_table <- renderUI({
  # print(dfSummary(getData()), method = "render")
  #})
  
  
  
  #investigating Missing Values
  output$glimpse_missing_variables <- renderPrint({
    #disselect ID column
    data <- react$cleanData2
    m <-
      is.na(data) + 0 # this is a trick that transforms Logical to Binary
    cm <- colMeans(m)
    m <- m[, cm > 0 & cm < 1, drop = FALSE]
    head(m)
  })
  
  output$selected_result_miss_vars <- renderText({
    data <- react$cleanData2
    m <-
      is.na(data) + 0 # this is a trick that transforms Logical to Binary
    cm <- colMeans(m)
    m <-
      m[, cm > 0 &
          cm < 1, drop = FALSE] #remove none-missing or all-missing variables
    if(is.null(m)) {
      return("")
    }
    m_split <- strsplit(colnames(m), " ")
    return(paste(" . ", m_split))
  })
  
  #output$selected_fruit <- renderText({
  #  data <- react$cleanData2
  #  m <- is.na(data) + 0 # this is a trick that transforms Logical to Binary
  #  cm <- colMeans(m)
  #  m <- m[, cm > 0 & cm < 1, drop = FALSE] #remove none-missing or all-missing variables
  #  my_words <- strsplit(colnames(m), " ")
  #  paste("You selected", m, ",\n")
  #})
  
  output$cor_missing <- renderPlot({
    data <- react$cleanData2
    m <-
      is.na(data) + 0 # this is a trick that transforms Logical to Binary
    cm <- colMeans(m)
    m <-
      m[, cm > 0 &
          cm < 1, drop = FALSE] #remove none-missing or all-missing variables
    corrgram::corrgram(cor(m),
                       order = input$Order_cor_rec_inves,upper.panel = panel.cor,cor.method = "pearson",
                       abs = TRUE)
    title(main = "Variable missing value correlation",
          sub = "Notice whether variables are missing in sets")
  })
  
  #corrgram::corrgram(
  #  data_df_VC_noNA,
  #  order = input$Order_cor_raw,
  #  abs = input$abs_raw,
  #  upper.panel = panel.cor,
  #  cor.method = input$cor_method_sel_raw,
  #  main = "Correlation Chart for Raw Data"
  observe({
    data <- getData()
    choices <- colnames(data[, ])
    
    updateSelectInput(session, "tree_variable_sel", choices = choices, selected = "DEATH_RATE")
  })
  
  output$Tree_raw <- renderPlot({
    var_s <- input$tree_variable_sel
    data <- getData()
    # step 1
    data <- data[order(data[[var_s]]), ]
    data[, var_s] <- 1:nrow(data)
    # step 2
    data$missingness <- apply(X = is.na(data),
                              MARGIN = 1,
                              FUN = sum)
    # step 3
    #formula <- as.formula(paste("missingness ~ . ",- str(var_s)))
    tree <- caret::train(
      missingness ~ ., 
      data = data,
      method = "rpart",
      na.action = na.rpart
    )
    rpart.plot(
      tree$finalModel,
      main = "TUNED: Predicting the number of missing variables in an observation",
      #sub = "Check whether the outcome variable is an important variable",
      roundint = TRUE,
      clip.facs = TRUE
    )
  })
  
  output$Tree_rec <- renderPlot({
    var_s <- input$tree_variable_sel
    data <- react$cleanData2
    # step 1
    data <- data[order(data[[var_s]]), ]
    data[, var_s] <- 1:nrow(data)
    # step 2
    data$missingness <- apply(X = is.na(data),
                              MARGIN = 1,
                              FUN = sum)
    # step 3
    tree <- caret::train(
      missingness ~ .,
      data = data,
      method = "rpart",
      na.action = na.rpart
    )
    rpart.plot(
      tree$finalModel,
      main = paste(
        "TUNED: Predicting the number of missing variables in an observation",
        "Thresholds VarMiss:",
        input$VarThreshold,
        "%, ",
        "ObsMiss:",
        input$ObsThreshold,
        "%"
      ),
      #sub = "Check whether the outcome variable is an important variable",
      roundint = TRUE,
      clip.facs = TRUE
    )
  })
  
  #Table for Train & Test
  #create data table
  output$Cleaned_Data_Table_train <- DT::renderDataTable({
    # create data table
    DT::datatable(
      data = react$train,
      options = list(
        paging = TRUE,
        pageLength = 10,
        width = "50%",
        pagingType = "full_numbers"
      )
    )
  })
  
  output$Cleaned_Data_Table_test <- DT::renderDataTable({
    # create data table
    DT::datatable(
      data = react$test,
      options = list(
        paging = TRUE,
        pageLength = 10,
        width = "50%",
        pagingType = "full_numbers"
      )
    )
  })
  
  observe({
    data <- react$cleanData2
    req(data)
    rec <- recipes::recipe(DEATH_RATE ~ ., data = data) %>%
      update_role('CODE', new_role = 'id') %>%  #CODE is not a predictor
      update_role('OBS_TYPE', new_role = 'split') #obs_type is not a predictor
    if (input$ImpMethod == "KNN") {
      rec <- rec %>%
        step_impute_knn(all_predictors(), neighbors = input$KNN_Neighbors) %>%
        step_naomit(all_predictors())
      #} else if (input$ImpMethod == "Partial Del") {
      #rec <- rec %>%
      #  step_naomit()
    } else if (input$ImpMethod == "Mean") {
      rec <- rec %>%
        step_impute_mean(all_numeric()) %>% #dividing each numeric predictor variable by its standard deviation
        step_naomit(all_predictors(),-all_numeric()) 
    } else if (input$ImpMethod == "Median") {
      rec <- rec %>%
        step_naomit(all_factor())%>%
        step_impute_median(all_numeric()) #dividing each numeric predictor variable by its standard deviation
    }
    #else if (input$ImpMethod == "Bagging") {
    #  rec <- rec %>%
    #    step_impute_bag(all_predictors(), B = 5, id = NULL)
    #}
    if (input$transform_outcome){
    if (input$Method_Selection == "Yeo_Johnson"){
      rec <- rec %>%
        step_YeoJohnson(all_numeric(), -all_outcomes())
    }else if (input$Method_Selection == "Box_Cox"){
      rec <- rec %>%
        step_BoxCox(all_numeric(), -all_outcomes())
    }else if (input$Method_Selection== "No_Transformation")
    {
      rec <- rec
    }} else {
      if (input$Method_Selection == "Yeo_Johnson"){
        rec <- rec %>%
          step_YeoJohnson(all_numeric())
      }else if (input$Method_Selection == "Box_Cox"){
        rec <- rec %>%
          step_BoxCox(all_numeric())
      }else if (input$Method_Selection== "No_Transformation")
      {
        rec <- rec
      }
    }
    
    if (input$center_final) {
      rec <- rec %>%
        step_center(all_numeric(),-has_role('outcome'))  #subtract the mean
    }
    if (input$scale_final) {
      rec <- rec %>%
        step_scale(all_numeric(),-has_role("outcome"))
    }
    
    rec <- rec %>%
      step_naomit(all_predictors(),-all_numeric()) %>%
      step_dummy(all_predictors(),-all_numeric())
    
    react$recipe <- rec
  })
  
  #Imputing Missing Values
  output$Imputed_Data_train <- renderDataTable({
    data <- react$rec_imp_train
    datatable(data)
  })
  
  output$Missing <- renderPlot({
    data <- react$rec_imp_full
    visdat::vis_dat(data) +
      labs(
        title = paste(
          "Thresholds VarMiss:",
          input$VarThreshold,
          "%, ",
          "ObsMiss:",
          input$ObsThreshold,
          "%"
        )
      )
  })
  
  output$Imputed_Data_test <- renderDataTable({
    data <- react$rec_imp_test
    datatable(data)
  })
  
  #output$Missing_test <- renderPlot({
  #  data <- react$rec_imp_test
  #  visdat::vis_dat(data) +
  #    labs(
  #      title = paste(
  #        "Thresholds VarMiss:",
  #        input$VarThreshold,
  #        "%, ",
  #        "ObsMiss:",
  #        input$ObsThreshold,
  #        "%"
  #      )
  #    )
  #})
  
  observe({
    req(react$rec_imp_full)
    data <- react$rec_imp_full
    data <- data %>% select_if(is.numeric)
    choices <- colnames(data[, ])
    updateSelectizeInput(session, "Boxplot_outlier_variables_", choices = choices, selected = "VAX_RATE")
  })
  
  #Lower Dimension Outliers
  #histgram
  observe({
    req(react$rec_imp_full)
    data <- react$rec_imp_full
    data <- data %>% select_if(is.numeric)
    choices <- colnames(data[, ])
    updateSelectizeInput(session, "hist_outlier_variables1", choices = choices, selected = "VAX_RATE")
  })
  output$hist_outliers <- renderPlot({
    data <- react$rec_imp_full
    bins <- input$hist_outlier_bins
    sel_var <- input$hist_outlier_variables1
    ggplot(data = data) +
      geom_histogram(mapping = aes(x = !!sym(sel_var)), bins = bins) +
      labs(title = paste("Histogram for ", sel_var), x = sel_var, y = "Count")
    
  })
  
  #boxplot
  output$boxplot_outliers <- renderPlot({
    data <- react$rec_imp_full
    coef <- input$Boxplot_outlier_slider
    data = data.frame(data)

    # Use input$Boxplot_outlier_variables_ to select the variable to plot
    limits <- boxplot.stats(x = data[, input$Boxplot_outlier_variables_], coef = coef)$stats
    data$label <- ifelse(data[, input$Boxplot_outlier_variables_] < limits[1] | 
                           data[, input$Boxplot_outlier_variables_] > limits[5], rownames(data), NA)
    
    ggplot(data = data, mapping = aes(x = data[, input$Boxplot_outlier_variables_], y = 0)) +
      geom_boxplot(coef = coef, outlier.colour = "red") +
      ggrepel::geom_text_repel(mapping = aes(label = label), max.overlaps = 50, na.rm=TRUE) +
      labs(title = paste(input$Boxplot_outlier_variables_, "Boxplot using", coef, "as IQR Multplier")) +
      theme(axis.title.y = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank())
  })
  
  #bag plot
  observe({
    req(react$rec_imp_full)
    data <- react$rec_imp_full
    data <- data %>% select_if(is.numeric)
    choices <- colnames(data[, ])
    updateSelectizeInput(session, "Bagplot_outlier_variables_", choices = choices)
  })
  
  output$bagplot_outliers <- renderPlot({
    data <- react$rec_imp_full
    x_var <- input$Bagplot_outlier_variables_
    factor <- input$Bag_factor
    aplpack::bagplot(x = data[[x_var]], y = data$DEATH_RATE, factor = factor, show.bagpoints = FALSE, xlab = input$Bagplot_outlier_variables_, ylab = "DEATH_RATE")
  })
  
  output$bag_outliers_table <- renderTable({
    data <- react$rec_imp_full
    x_var <- input$Bagplot_outlier_variables_
    factor <- input$Bag_factor
    bag <- aplpack::bagplot(x = data[[x_var]], y = data$DEATH_RATE, factor = factor, show.bagpoints = FALSE, create.plot = FALSE)
    values <- as.data.frame(bag$pxy.outlier)
    if (x_var == "POPULATION"){name = "POPULATION"}
    outliers <- dplyr::inner_join(x = data, y = values, by = setNames(c("x", "y"), c(input$Bagplot_outlier_variables_, "DEATH_RATE")))
  })
  

  output$manh_outlier_plot <- renderPlot({
    processed <- recipe(~ ., data = react$rec_imp_full) %>%
      step_rm(all_nominal_predictors()) %>% #remove any nominals 
      step_naomit(everything() ) %>% #remove any observations with missing values
      step_nzv(all_predictors()) %>%  # remove zero & near zero variance predictor variables
      step_scale(all_numeric_predictors()) %>% 
      step_lincomb(all_numeric_predictors()) %>%   # remove predictors that are linear combinations of other predictors
      prep(data = react$rec_imp_full) %>% # train these steps
      bake(new_data =  react$rec_imp_full)
    
    Covar <- var(processed) # calculate the covariance matrix
    Means <- colMeans(processed) # calculate variable means 
    md2 <- mahalanobis(x = processed, center = Means, cov = Covar)
    names(md2) <- rownames(processed)
    
    threshold <- qchisq(p = 0.99999, df = ncol(processed))
    label <- ifelse(md2 > threshold, names(md2), NA)
    Observations <- ifelse(md2 > threshold, "outlier", "non-outlier")
    id <- (1:length(md2))/length(md2)
    data <- data.frame(md2, label, id, Observations)
    
    ggplot(data = data, mapping = aes(y = md2, x = id)) +
      geom_point(mapping = aes(colour = Observations)) +
      ggrepel::geom_text_repel(max.overlaps = 50, mapping = aes(label = label)) +
      scale_colour_manual(values = c("blue", "red")) +
      labs(y = "Mahalanobis distance squared", 
           x = "Complete Observations", 
           title = paste("Outlier pattern using", round(threshold,1), "threshold")) +
      geom_hline(yintercept = threshold, colour = "black") +
      scale_x_continuous(breaks = c(0, 0.5, 1), labels = c("0%", "50%", "100%"))
    
  })
  
  output$cook_outlier_plot <- renderPlot({
    processed <- recipe(DEATH_RATE ~ ., data = react$rec_imp_full) %>%
      step_rm(all_nominal_predictors()) %>% #remove any nominals
      step_naomit(everything()) %>% # remove any obs that have missing values
      step_nzv(all_predictors()) %>%  # remove near zero variance predictor variables
      step_lincomb(all_numeric_predictors()) %>%   # remove predictors that are linear combinations of other predictors
      step_corr(all_numeric_predictors()) %>% # remove high correlation
      prep(data = react$rec_imp_full) %>% 
      bake(new_data = react$rec_imp_full)
    
    lmod <- glm(formula = DEATH_RATE ~ ., data = processed, family = gaussian)
    dc <- cooks.distance(lmod)
    mean_cook <- mean(dc)

    observe({
      react$rec_imp_full
      updateSliderInput(session, "cook_threshold", max = 4 * mean_cook + 0.005)
    })
    threshold <- input$cook_threshold #1.4  # this is an empirical way to assign a threshold
    id <- (1:length(dc))/length(dc)
    label <- ifelse(dc > threshold, rownames(processed), NA)
    Observations <- ifelse(dc > threshold, "outlier", "non-outlier")
    data <- data.frame(dc, id, label, Observations)
    
    ggplot(data = data, mapping = aes(y = dc, x = id)) +
      geom_point(mapping = aes(colour = Observations)) +
      ggrepel::geom_text_repel(max.overlaps = 50, mapping = aes(label = label)) +
      scale_colour_manual(values = c("blue", "red")) +
      labs(y = "Cook's distance", 
           x = "Complete Observations", 
           title = paste("Outlier pattern using", round(threshold,3), "threshold")) +
      geom_hline(yintercept = threshold, color = "black") +
      scale_x_continuous(breaks = c(0, 0.5, 1), labels = c("0%", "50%", "100%")) 
    
  })
  
  output$local_outlier_plot <- renderPlot({
    processed <- recipe(~ ., data = react$rec_imp_full) %>%
      step_rm(all_nominal_predictors()) %>% #remove any nominal variables
      step_naomit(everything()) %>% # remove obs that have missing values
      step_scale(all_numeric_predictors()) %>%  # scale by standard deviations
      prep(data = react$rec_imp_full) %>% 
      bake(new_data = react$rec_imp_full)
    
    mat <- as.matrix(processed)
    minPoints <- input$olf_minpoints     # assume 4 neighbours
    threshold <- input$olf_threshold
    lof <- dbscan::lof(mat, minPts = minPoints)
    id <- (1:length(lof))/length(lof)
    label <- ifelse(lof > threshold, rownames(processed), NA)
    Observations <- ifelse(lof > threshold, "outlier", "non-outlier")
    data <- data.frame(lof, id, label, Observations)
    
    ggplot(data = data, mapping = aes(y = lof, x = id)) +
      geom_point(mapping = aes(colour = Observations)) +
      geom_text_repel(max.overlaps = 50, mapping = aes(label = label)) +
      scale_colour_manual(values = c("blue", "red")) +
      scale_y_continuous(limits = c(0, NA)) +
      labs(y = "LOF", x = "Complete Observations", title = paste("Outlier pattern using minPoints =", minPoints, "and threshold =",threshold)) +
      geom_hline(yintercept = threshold, color = "black") +
      scale_x_continuous(breaks = c(0, 0.5, 1), labels = c("0%", "50%", "100%"))
    
    
  })
  
  output$Isolation_Forest <- renderPlot({
    data <- react$rec_imp_full
    threshold <- input$iso_threshold
    itree <- isotree::isolation.forest(data)
    scores <- predict(itree, newdata = data)
    names(scores) <- rownames(data)
    isfOutliers <- scores > threshold
    data <- data.frame(
      scores       = scores, 
      id           = (1:length(scores))/length(scores),
      Observations = ifelse(isfOutliers, "outlier", "non-outlier"),
      label        = ifelse(isfOutliers, names(scores), NA)
    )
    
    ggplot(data = data, mapping = aes(y = scores, x = id)) +
      geom_point(mapping = aes(colour = Observations)) +
      geom_text_repel(max.overlaps = 50, mapping = aes(label = label)) +
      scale_colour_manual(values = c("blue", "red")) +
      scale_y_continuous(limits = c(0.3333, NA)) +
      labs(y = "Iso Score", x = "Complete Observations", title = paste("Outlier pattern using IsollationForest with threshold =",threshold)) +
      geom_hline(yintercept = threshold, color = "black") +
      scale_x_continuous(breaks = c(0, 0.5, 1), labels = c("0%", "50%", "100%"))
  })
  
  output$SVM_table <- renderTable({
    processed <- recipe(~ ., data = react$rec_imp_full) %>%
      step_rm(all_nominal_predictors()) %>% # remove any nominal variables
      step_naomit(everything()) %>% # remove any obs that have missing values
      prep(data = react$rec_imp_full) %>% 
      bake(new_data = react$rec_imp_full)
    mat <- as.matrix(processed)
    model <- e1071::svm(mat, y = NULL, type = 'one-classification', nu = input$svm_nu, scale = TRUE, kernel = "linear")
    svmOutlier <- !predict(model, mat)
    rownames(processed)[svmOutlier]
  })
  
  #Outliers Transformation
  output$YeoJtable <- renderDataTable({
    req(react$recipe)
    data <- prep(react$recipe, training = react$cleanData2) %>%
      bake(new_data = react$cleanData2)
    datatable(data)
  })

  observe({
    req(react$cleanData2)
    req(react$recipe)
    data <- prep(react$recipe, training = react$cleanData2) %>%
      bake(new_data = react$cleanData2)
    data <- data %>% select_if(is.numeric)
    choices <- colnames(data[, ])
  
    updateSelectizeInput(session, "Transform_var", choices = choices)
  })
  
  output$before_johnson <- renderPlot({
    req(react$recipe_no_trans)
    data <- prep(react$recipe_no_trans, data = react$cleanData2) %>%
      bake(new_data = react$cleanData2)
    data <- data %>% select_if(is.numeric)
    
    plot(density(data[[input$Transform_var]]), main = paste(input$Transform_var," BEFORE",input$Method_Selection , "Transform"))
  })
 
  output$after_johnson <- renderPlot({
    req(react$recipe)
    data <- prep(react$recipe, data = react$cleanData2) %>%
      bake(new_data = react$cleanData2)
    data <- data %>% select_if(is.numeric)

    plot(density(data[[input$Transform_var]]), main = paste(input$Transform_var," AFTER",input$Method_Selection , "Transform"))
    })
  
  
  
  
  
#Model based outlier detection

  
  
  #Train Model
  #Model Training
  
  observe({
    req(input$Go)
    isolate({
      req(react$recipe, react$train)
      mod <- caret::train(react$recipe,
                          data = react$train,
                          method = "glmnet")
    })
    react$model <- mod
  })
  
  output$Summary_Model <- renderPrint({
    mod <- react$model
    if (is.null(mod)) {
      return("Model is yet trained, please check the selections above and click on the 'train' button.")
    }
    req(mod)
    print(mod)
  })
  
  observe({
    data <- input$ImpMethod
    updateSelectInput(session, "ImpMethod2", selected = data)
  })
  
  observe({
    data <- input$ImpMethod2
    updateSelectInput(session, "ImpMethod", selected = data)
  })
  
  #set training dataset show or hide
  table_shown <- reactiveVal(FALSE)
  observeEvent(input$show_table, {
    table_shown(!table_shown())
  })
  
  output$Summary_Imputed_train <- renderPrint({
    if (table_shown()) {
      # Return your table data here
      
    req(react$recipe)
    rec_imputed <- react$recipe %>%
      prep(training = react$train) %>%
      juice()
    rec_imputed <- rec_imputed[rec_imputed$OBS_TYPE == 'Train', ]
    summary(rec_imputed)
    }
  })
  
  #Prediction
  observe({
    req(input$Go_Prediction)
    isolate({
      req(react$recipe, react$test)
      req(react$model)
      rec_imputed <- prep(react$recipe, testing = react$test)
      preds = predict(object = react$model, newdata = react$test)
      # do something with the predictions, for example update a reactive variable
    })
    result <- cbind(react$test, preds)
    test_with_pred <- result[complete.cases(result$preds),]
    test_with_pred$Residual <- test_with_pred$preds - test_with_pred$DEATH_RATE
    react$test_with_pred <- test_with_pred
  })
  
  output$RMSE_Model_test <- renderPrint({
    test_with_pred <- react$test_with_pred
    if (is.null(test_with_pred)) {
      return("Prediction is yet ready, please click on the 'Predict' button.")
    }
    rmse <-
      sqrt(mean((
        test_with_pred$Residual
      ) ^ 2))
    print(rmse)
  })
  
  
  output$Summary_Model_test <- renderPrint({
    predictions <- react$test_with_pred
    if (is.null(predictions)) {
      return("Prediction is yet ready, please click on the 'Predict' button.")
    }
    req(predictions)
    summary(predictions$preds)
  })
  
  #set training dataset show or hide
  table_shown_test <- reactiveVal(FALSE)
  observeEvent(input$show_test_table, {
    table_shown_test(!table_shown_test())
  })
  
  output$Summary_Imputed_test <- renderPrint({
    if (table_shown_test()) {
    req(react$recipe)
    rec_imputed <- react$recipe %>%
      prep(training = react$test) %>%
      juice()
    rec_imputed <- rec_imputed[rec_imputed$OBS_TYPE == 'Test', ]
    summary(rec_imputed)
    }
  })
  
  #residuals plots:
  observe({
    req(react$recipe, react$train)
    req(react$model)
    rec_imputed <- prep(react$recipe, training = react$train)
    preds = predict(object = react$model, newdata = react$train)
    result <- cbind(react$train, preds)
    train_with_pred <-
      result[complete.cases(result$preds),]
    train_with_pred$Residual <- train_with_pred$preds - train_with_pred$DEATH_RATE
    react$train_with_pred <- train_with_pred
  })
  
  output$Train_residuals <- renderPrint({
    train_data <- react$train_with_pred
    test_data <- react$test_with_pred
    if (is.null(test_data$preds)) {
      return("")
    }
    combined <- rbind(train_data, test_data)
    print(combined)
  })
  
  output$both_residual_boxplot <- renderPlot({
    train_data <- react$train_with_pred
    test_data <- react$test_with_pred
    if (is.null(test_data$preds)) {
      return("")
    }
    
    combined <- rbind(train_data, test_data)
    
    coef <- input$Residual_outlier_slider
    data2 <- combined
    limits <- boxplot.stats(x = data2$Residual, coef = coef)$stats
    data2$label <- ifelse(data2$Residual < limits[1] | data2$Residual > limits[5], rownames(data2), NA)
    ggplot(data2, aes(y = 1, x = Residual, label = label)) +
      geom_boxplot(coef = coef, outlier.colour = "red") +
      ggrepel::geom_text_repel(mapping = aes(label = label), max.overlaps = 50, na.rm=TRUE) +
      labs(title = paste("Boxplot using", coef, "as IQR Multplier")) +
      theme(axis.title.y = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank())
  })
  
  output$train_residual_boxplot <- renderPlot({
    train_data <- react$train_with_pred
    test_data <- react$test_with_pred
    if (is.null(test_data$preds)) {
      return("")
    }

    coef <- input$Residual_outlier_slider
    data2 <- train_data
    limits <- boxplot.stats(x = data2$Residual, coef = coef)$stats
    data2$label <- ifelse(data2$Residual < limits[1] | data2$Residual > limits[5], rownames(data2), NA)
    ggplot(data2, aes(y = 1, x = Residual, label = label)) +
      geom_boxplot(coef = coef, outlier.colour = "red") +
      ggrepel::geom_text_repel(mapping = aes(label = label), max.overlaps = 50, na.rm=TRUE) +
      labs(title = paste("Boxplot using", coef, "as IQR Multplier")) +
      theme(axis.title.y = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank())
  })
  
  output$test_residual_boxplot <- renderPlot({
    train_data <- react$train_with_pred
    test_data <- react$test_with_pred
    if (is.null(test_data$preds)) {
      return("")
    }
    
    coef <- input$Residual_outlier_slider
    data2 <- test_data
    limits <- boxplot.stats(x = data2$Residual, coef = coef)$stats
    data2$label <- ifelse(data2$Residual < limits[1] | data2$Residual > limits[5], rownames(data2), NA)
    ggplot(data2, aes(y = 1, x = Residual, label = label)) +
      geom_boxplot(coef = coef, outlier.colour = "red") +
      ggrepel::geom_text_repel(mapping = aes(label = label), max.overlaps = 50, na.rm=TRUE) +
      labs(title = paste("Boxplot using", coef, "as IQR Multplier")) +
      theme(axis.title.y = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank())
  })
  

  
  
  
  
  
  
  
  
  

  observe({
    # remove excessively missing Variables
    data <- getData()
    vRatio <- apply(X = data,
                    MARGIN = 2,
                    FUN = pMiss)
    react$cleanData1 <- data[, vRatio < input$VarThreshold]
  })
  
  observe({
    # remove excessively missing Obs
    data <- react$cleanData1
    req(data)
    oRatio <- apply(X = data,
                    MARGIN = 1,
                    FUN = pMiss)
    react$cleanData2 <- data[oRatio < input$ObsThreshold,]
  })
  
  observe({
    # remove excessively missing Obs
    data <- react$cleanData2
    req(data)
    full_choices <- names(data)
    react$full_choices <- full_choices
  })
  
  observe({
    # remove excessively missing Obs
    data <- react$cleanData2
    req(data)
    numeric_data <- data %>% select_if(is.numeric)
    react$numeric_data <- numeric_data
  })
  
  observe({
    # remove excessively missing Obs
    data <- react$cleanData2
    req(data)
    numeric_data <- data %>% select_if(is.numeric)
    #numeric_choices <- colnames(numeric_data[ ,])
    numeric_choices <- names(numeric_data)
    react$numeric_choices <- numeric_choices
  })
  
  observe({
    # remove excessively missing Obs
    data <- react$cleanData2
    req(data)
    factor_data <- data %>% select_if(is.factor)
    react$factor_data <- factor_data
  })
  
  observe({
    # remove excessively missing Obs
    data <- react$cleanData2
    req(data)
    factor_data <- data %>% select_if(is.factor)
    #factor_choices <- colnames(factor_data[ ,])
    factor_choices <- names(factor_data)
    react$factor_choices <- factor_choices
  })
  
  observe({
    # create training dataset
    data <- react$cleanData2
    req(data)
    train <- data[data$OBS_TYPE == 'Train', ]
    react$train <- train
  })
  
  observe({
    # create testing dataset
    data <- react$cleanData2
    req(data)
    test <- data[data$OBS_TYPE == 'Test', ]
    react$test <- test
  })
  
  observe({
    req(react$recipe)
    rec_imp_full <- prep(react$recipe, data = react$cleanData2) %>%
      bake(new_data = react$cleanData2)
    react$rec_imp_full <- rec_imp_full
  })
  
  observe({
    req(react$recipe)
    rec_imp_train <- prep(react$recipe, training = react$train) %>%
      bake(new_data = react$train)
    react$rec_imp_train <- rec_imp_train 
  })
  
  observe({
    req(react$recipe)
    rec_imp_test <- prep(react$recipe, testing = react$test) %>%
      bake(new_data = react$test)
    react$rec_imp_test <- rec_imp_test 
  })
  
  #observe({
  #  data <- react$rec_imp_full
  #  req(data)
  #  rec <- recipes::recipe(DEATH_RATE ~ ., data = data)
  #  if (input$Method_Selection == "Yeo_Johnson"){
  #  rec <- rec %>%
  #    step_YeoJohnson(all_numeric())
  #  }else if (input$Method_Selection == "Box_Cox"){
  #    rec <- rec %>%
  #      step_BoxCox(all_numeric())
  #  }
  #  #else if (input$Method_Selection== "No_Transformation")
  #  #{
  #    #rec <- rec
  #  #}
  #  react$transform <- rec
  #})
  
  observe({
    data <- react$cleanData2
    req(data)
    rec <- recipes::recipe(DEATH_RATE ~ ., data = data) %>%
      update_role('CODE', new_role = 'id') %>%  #CODE is not a predictor
      update_role('OBS_TYPE', new_role = 'split') #obs_type is not a predictor
    if (input$ImpMethod == "KNN") {
      rec <- rec %>%
        step_impute_knn(all_predictors(), neighbors = input$KNN_Neighbors) %>%
        step_naomit(all_predictors())
      #} else if (input$ImpMethod == "Partial Del") {
      #  rec <- rec %>%
      #    step_naomit()
    } else if (input$ImpMethod == "Mean") {
      rec <- rec %>%
        step_impute_mean(all_numeric()) %>% #dividing each numeric predictor variable by its standard deviation
        step_naomit(all_predictors(),-all_numeric()) 
    } else if (input$ImpMethod == "Median") {
      rec <- rec %>%
        #step_naomit(all_factor())%>%
        step_impute_median(all_numeric())%>% #dividing each numeric predictor variable by its standard deviation
        step_naomit()
        }
    #else if (input$ImpMethod == "Bagging") {
    #  rec <- rec %>%
    #    step_impute_bag(all_predictors(), B = 5, id = NULL)
    #}
    
    if (input$center_final) {
      rec <- rec %>%
        step_center(all_numeric(),-has_role('outcome'))  #subtract the mean
    }
    if (input$scale_final) {
      rec <- rec %>%
        step_scale(all_numeric(),-has_role("outcome"))
    }
    
    rec <- rec %>%
      step_naomit(all_predictors(),-all_numeric()) %>%
      step_dummy(all_predictors(),-all_numeric())
    react$recipe_no_trans <- rec
  })
  
  observe({
    data <- input$VarThreshold
    updateSliderInput(session, "VarThreshold_2", value = data)
  })
  
  observe({
    data <- input$VarThreshold_2
    updateSliderInput(session, "VarThreshold", value = data)
  })
  
  observe({
    data <- input$ObsThreshold
    updateSliderInput(session, "ObsThreshold_2", value = data)
  })
  
  observe({
    data <- input$ObsThreshold_2
    updateSliderInput(session, "ObsThreshold", value = data)
  })
  
  observe({
    data <- input$Method_Selection
    updateSelectInput(session, "Method_Selection_2", selected = data)
  })
  
  observe({
    data <- input$Method_Selection_2
    updateSelectInput(session, "Method_Selection", selected = data)
  })
  
  observe({
    data <- input$transform_outcome
    updateCheckboxInput(session, "transform_outcome_2", value = data)
  })
  
  observe({
    data <- input$transform_outcome_2
    updateCheckboxInput(session, "transform_outcome", value = data)
  })
  
  
  
}