# Define UI for app
ui <- fluidPage(
  # App title
  theme = shinytheme("flatly"),
  titlePanel(
    HTML('<h1><strong>Assignment 2 - <em>Zhongya Ge</em></strong></h1>')
  ),
  shinyjs::useShinyjs(),
  tabsetPanel(
    #first panel is for Overview
    tabPanel(
      HTML(
        '<button type="button" class="btn btn-primary"><strong>OVERVIEW</strong></button>'
      ),
      tabsetPanel(
        #first subpanel is for structure and summary for raw data
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Structure and Summary of <strong><em>Raw Data</em></strong></button>'
          ),
          HTML(
            '<h3 style="text-align: left; padding-left: 10%;"><strong>Variable HEALTHCARE_COST Indicating:</strong></h3>'
          ),
          radioGroupButtons(
            inputId = "Transfer_for_Healthcare_cost",
            label = "HEALTHCARE_COST Process:",
            choices = c(
              "Not Applicable - Shadown Column to be created",
              "Not Avaliable - No Shadown Column to be created   "
              
            ),
            status = "primary",
            checkIcon = list(
              yes = icon("ok",
                         lib = "glyphicon"),
              no = icon("remove",
                        lib = "glyphicon")
            )
          ),
          HTML(
            '<h3 style="text-align: left; padding-left: 10%;"><strong>Data Glimpse</strong></h3>'
          ),
          withSpinner(verbatimTextOutput("glimpse_raw", placeholder = TRUE)),
          HTML(
            '<h3 style="text-align: left; padding-left: 10%;"><strong>Data Summary</strong></h3>'
          ),
          withSpinner(verbatimTextOutput("summary_raw", placeholder = TRUE))
        ),
        #second subpanel in Overview is for summary table which is the result of dfSummary() function.
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Summary Table</button>'
          ),
          withSpinner(uiOutput("summary_table", placeholder = TRUE))
        ),
        #third subpanel is for datatable of raw data very detailed
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">DATATABLE of Raw Data</button>'
          ),
          br(),
          p("Explore ",
            span("all dataset", style = "color:blue"), ":"),
          DT::dataTableOutput(outputId = "Ass2Data"),
          style = "color:black; background-color: white;"
        ),
        #tabPanel(
        #  HTML(
        #    '<button type="button" class="btn btn-primary">Processed Data Summary</button>'
        #  ),
        #  br(),
        #  withSpinner(verbatimTextOutput("glimpse_processed_data", placeholder = TRUE)),
        #  withSpinner(verbatimTextOutput("summary_processed_data", placeholder = TRUE))
        #)
      )
    ),
    
    #second panel is for Exploratory Data Analysis
    tabPanel(
      HTML(
        '<button type="button" class="btn btn-primary"><strong>EXPLORATORY DATA ANALYSIS </strong></button>'
      ),
      tabsetPanel(
        #first subpanel is for boxplot
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">BoxPlot</button>'
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Raw Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "VariablesBox_raw",
                label = "Show variables:",
                choices = numeric_choices,
                multiple = TRUE,
                selected = numeric_choices
              ),
              checkboxInput(
                inputId = "select_all_vars_boxplot_raw",
                label = "Show All Variables",
                value = TRUE
              ),
              numericInput(
                inputId = "boxplot_IQR_raw",
                label = "IQR selection (from 0 to 4):",
                value = 1.5,
                min = 0,
                max = 4,
                step = 0.1
              ),
              checkboxInput(
                inputId = "center_Box_raw",
                label = "Center",
                value = TRUE
              ),
              checkboxInput(
                inputId = "scale_Box_raw",
                label = "Scale",
                value = TRUE
              ),
              checkboxInput(inputId = "show_Outliers_BoxPlot_raw", "Show Outliers ID", value = TRUE),
              width = 3
            ),
            mainPanel(
              plotOutput(outputId = "Boxplot_raw"),
              uiOutput(outputId = "Boxplot_raw_result")
            )
          ),
          br(),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Cleaned Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "VariablesBox_rec",
                label = "Show variables:",
                choices = numeric_choices,
                multiple = TRUE,
                selected = numeric_choices
              ),
              checkboxInput(
                inputId = "select_all_vars_boxplot_rec",
                label = "Show All Variables",
                value = TRUE
              ),
              numericInput(
                inputId = "boxplot_IQR_rec",
                label = "IQR selection (from 0 to 4):",
                value = 1.5,
                min = 0,
                max = 4,
                step = 0.1
              ),
              checkboxInput(
                inputId = "center_Box_rec",
                label = "Center",
                value = TRUE
              ),
              checkboxInput(
                inputId = "scale_Box_rec",
                label = "Scale",
                value = TRUE
              ),
              checkboxInput(inputId = "show_Outliers_BoxPlot_rec", "Show Outliers ID", value = TRUE),
              width = 3
            ),
            mainPanel(
              plotOutput(outputId = "Boxplot_rec"),
              uiOutput(outputId = "Boxplot_rec_result")
            )
          )
        ),
        #second subpanel is for rising value chart
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Rising Value Chart</button>'
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Raw Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "VariablesRising_raw",
                label = "Show variables (at least 2 selections):",
                choices = numeric_choices,
                multiple = TRUE,
                selected = numeric_choices
              ),
              checkboxInput(
                inputId = "select_all_vars_Rising_raw",
                label = "Show All Variables",
                value = TRUE
              ),
              checkboxInput(
                inputId = "center_RV_raw",
                label = "Center",
                value = TRUE
              ),
              checkboxInput(
                inputId = "scale_RV_raw",
                label = "Scale",
                value = TRUE
              ),
              checkboxInput("show_legend_RV_raw", "Show legend", value = TRUE),
              width = 3
            ),
            mainPanel(plotOutput(outputId = "rising_value_chart_raw"))
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Cleaned Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "VariablesRising_rec",
                label = "Show variables (at least 2 selections):",
                choices = numeric_choices,
                multiple = TRUE,
                selected = numeric_choices
              ),
              checkboxInput(
                inputId = "select_all_vars_Rising_rec",
                label = "Show All Variables",
                value = TRUE
              ),
              checkboxInput(
                inputId = "center_RV_rec",
                label = "Center",
                value = TRUE
              ),
              checkboxInput(
                inputId = "scale_RV_rec",
                label = "Scale",
                value = TRUE
              ),
              checkboxInput("show_legend_RV_rec", "Show legend", value = TRUE),
              width = 3
            ),
            mainPanel(plotOutput(outputId = "rising_value_chart_rec"))
          )
        ),
        #third subpanel is for histogram
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Histogram</button>'
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Raw Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Variables_hist_raw",
                label = "Show variables:",
                choices = numeric_choices,
                multiple = FALSE,
                selected = c("DEATH_RATE")
              ),
              sliderInput(
                inputId = "hist_bins_raw",
                label = "Number of bins:",
                min = 10,
                max = 60,
                value = 50
              ),
              width = 3
            ),
            mainPanel(
              plotlyOutput(
                outputId = "histogram_chart_raw",
                width = "100%",
                height = "100%"
              ),
            )
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Cleaned Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Variables_hist_rec",
                label = "Show variables:",
                choices = numeric_choices,
                multiple = FALSE,
                selected = c("DEATH_RATE")
              ),
              sliderInput(
                inputId = "hist_bins_rec",
                label = "Number of bins:",
                min = 10,
                max = 60,
                value = 50
              ),
              width = 3
            ),
            mainPanel(
              plotlyOutput(
                outputId = "histogram_chart_rec",
                width = "100%",
                height = "100%"
              ),
            )
          )
        ),
        #fourth subpanel is for matplot
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Matplot</button>'
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Raw Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Variables_Matplot_raw",
                label = "Show variables:",
                choices = numeric_choices,
                multiple = TRUE,
                selected = numeric_choices
              ),
              checkboxInput(
                inputId = "select_all_vars_matplot_raw",
                label = "Show All Variables",
                value = TRUE
              ),
              checkboxInput(
                inputId = "center_Homo_raw",
                label = "Center",
                value = TRUE
              ),
              checkboxInput(
                inputId = "scale_Homo_raw",
                label = "Scale",
                value = TRUE
              ),
              width = 3
            ),
            mainPanel(plotOutput(outputId = "homogeneity_chart_raw"))
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Cleaned Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Variables_Matplot_rec",
                label = "Show variables:",
                choices = numeric_choices,
                multiple = TRUE,
                selected = numeric_choices
              ),
              checkboxInput(
                inputId = "select_all_vars_matplot_rec",
                label = "Show All Variables",
                value = TRUE
              ),
              checkboxInput(
                inputId = "center_Homo_rec",
                label = "Center",
                value = TRUE
              ),
              checkboxInput(
                inputId = "scale_Homo_rec",
                label = "Scale",
                value = TRUE
              ),
              width = 3
            ),
            mainPanel(plotOutput(outputId = "homogeneity_chart_rec"))
          )
        ),
        #fifth subpanel is for mosaic
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Mosaic</button>'
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Raw Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Variables_Mosaic_raw",
                label = "Show variables:",
                choices = factor_choices,
                multiple = TRUE,
                selected = factor_choices
              ),
              width = 3
            ),
            mainPanel(plotOutput(outputId = "Mosaic_raw"))
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Cleaned Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Variables_Mosaic_rec",
                label = "Show variables:",
                choices = factor_choices,
                multiple = TRUE,
                selected = factor_choices
              ),
              width = 3
            ),
            mainPanel(plotOutput(outputId = "Mosaic_rec"))
          )
        ),
        #sixth subpanel is for correlation
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Correlation</button>'
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Raw Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Variables_cor_raw",
                label = "Show variables:",
                choices = numeric_choices,
                multiple = TRUE,
                selected = numeric_choices
              ),
              checkboxInput(
                inputId = "select_all_vars_cor_raw",
                label = "Show All Variables",
                value = TRUE
              ),
              selectInput(
                inputId = "cor_method_sel_raw",
                label = "Select a correlation method:",
                choices = c("pearson", "kendall", "spearman")
              ),
              selectInput(
                inputId = "Order_cor_raw",
                label = "Select an order: ",
                choices = list(
                  "none" = FALSE,
                  "OLO" = "OLO",
                  "GW" = "GW",
                  "HC" = "HC"
                ),
                selected = "HC"
              ),
              checkboxInput(
                inputId = "abs_raw",
                label = "ABS",
                value = TRUE
              ),
              width = 3
            ),
            mainPanel(plotOutput(outputId = "AutoCorr_raw"))
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Cleaned Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Variables_cor_rec",
                label = "Show variables:",
                choices = numeric_choices,
                multiple = TRUE,
                selected = numeric_choices
              ),
              checkboxInput(
                inputId = "select_all_vars_cor_rec",
                label = "Show All Variables",
                value = TRUE
              ),
              selectInput(
                inputId = "cor_method_sel_rec",
                label = "Select a correlation method:",
                choices = c("pearson", "kendall", "spearman")
              ),
              selectInput(
                inputId = "Order_cor_rec",
                label = "Select an order: ",
                choices = list(
                  "none" = FALSE,
                  "OLO" = "OLO",
                  "GW" = "GW",
                  "HC" = "HC"
                ),
                selected = "HC"
              ),
              checkboxInput(
                inputId = "abs_rec",
                label = "ABS",
                value = TRUE
              ),
              width = 3
            ),
            mainPanel(plotOutput(outputId = "AutoCorr_rec"))
          )
        ),
        #seventh subpanel is for GGpair
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">GGpairs</button>'
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Raw Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Variable_gg_raw",
                label = "Show variables:",
                choices = numeric_choices,
                multiple = TRUE,
                selected = c("POPULATION", "POP_DENSITY", "DEATH_RATE")
              ),
              selectInput(
                inputId = "color_sel_ggpairs_raw",
                label = "Select a Variable for plotting color",
                choices = factor_choices,
                selected = c("HEALTHCARE_BASIS")
              ),
              width = 3
            ),
            mainPanel(withSpinner(plotOutput(outputId = "Ggpairs_raw")))
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Cleaned Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Variable_gg_rec",
                label = "Show variables:",
                choices = numeric_choices,
                multiple = TRUE,
                selected = c("POPULATION", "POP_DENSITY", "DEATH_RATE")
              ),
              selectInput(
                inputId = "color_sel_ggpairs_rec",
                label = "Select a Variable for plotting color",
                choices = factor_choices,
                selected = c("HEALTHCARE_BASIS")
              ),
              width = 3
            ),
            mainPanel(withSpinner(plotOutput(outputId = "Ggpairs_rec")))
          )
        ),
        #eighth subpanel is for missing vis
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Missing Vis</button>'
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Raw Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Variables_missing_raw",
                label = "Show variables:",
                choices = full_choices,
                multiple = TRUE,
                selected = full_choices
              ),
              checkboxInput(
                inputId = "select_all_vars_vis_raw",
                label = "Show All Variables",
                value = TRUE
              ),
              width = 3
            ),
            mainPanel(withSpinner(plotOutput(outputId = "vis_dat_raw")))
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Cleaned Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Variables_missing_rec",
                label = "Show variables:",
                choices = full_choices,
                multiple = TRUE,
                selected = full_choices
              ),
              checkboxInput(
                inputId = "select_all_vars_vis_rec",
                label = "Show All Variables",
                value = TRUE
              ),
              width = 3
            ),
            mainPanel(withSpinner(plotOutput(outputId = "vis_dat_rec")))
          )
        ),
        #nineth subpanel is for cluster missing
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Cluster Missing</button>'
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Raw Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Variables_missing2_raw",
                label = "Show variables:",
                choices = full_choices,
                multiple = TRUE,
                selected = full_choices
              ),
              checkboxInput(
                inputId = "select_all_vars_vis_missing_raw",
                label = "Show All Variables",
                value = TRUE
              ),
              checkboxInput(
                inputId = "cluster_raw",
                label = "Cluster missingness",
                value = FALSE
              ),
              width = 3
            ),
            mainPanel(withSpinner(plotOutput(outputId = "vis_miss_raw")))
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Cleaned Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Variables_missing2_rec",
                label = "Show variables:",
                choices = full_choices,
                multiple = TRUE,
                selected = full_choices
              ),
              checkboxInput(
                inputId = "select_all_vars_vis_missing_rec",
                label = "Show All Variables",
                value = TRUE
              ),
              checkboxInput(
                inputId = "cluster_rec",
                label = "Cluster missingness",
                value = FALSE
              ),
              width = 3
            ),
            mainPanel(withSpinner(plotOutput(outputId = "vis_miss_rec")))
          )
        ),
        #then subpanel is for variable importance
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Variable Importance</button>'
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Raw Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              numericInput(
                inputId = "top_display_raw",
                label = "Top n to display:",
                value = 5,
                min = 1,
                max = 40
              ),
              selectInput(
                inputId = "method_sel_raw",
                label = "Select a method for Variable Importance calculation:",
                choices = c("rf", "glm")
              ),,
              width = 3
            ),
            mainPanel(withSpinner(
              plotOutput(outputId = "Variable_Impor_raw")
            ))
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 20%;"><strong>Cleaned Data:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              numericInput(
                inputId = "top_display_rec",
                label = "Top n to display:",
                value = 5,
                min = 1,
                max = 40
              ),
              selectInput(
                inputId = "method_sel_rec",
                label = "Select a method for Variable Importance calculation:",
                choices = c("rf", "glm")
              ),
              width = 3,
            ),
            mainPanel(withSpinner(
              plotOutput(outputId = "Variable_Impor_rec")
            ))
          )
        ),
        #eleventh subpanel is for Pattern plot
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Pattern Plot</button>'
          ),
          br(),
          sidebarLayout(sidebarPanel(
            numericInput(
              inputId = "nsets_raw",
              label = "nsets = ",
              value = 5,
              min = 2,
              max = 10
            ),
            width = 3
          ),
          mainPanel(withSpinner(
            plotOutput(outputId = "Pattern_raw")
          ))),
          br(),
          sidebarLayout(sidebarPanel(
            numericInput(
              inputId = "nsets_rec",
              label = "nsets = ",
              value = 5,
              min = 0,
              max = 10
            ),
            width = 3
          ),
          mainPanel(withSpinner(
            plotOutput(outputId = "Pattern_rec")
          )))
        )
      )
    ),
    
    
    #third panel is for Processed Data Overview
    tabPanel(
      HTML(
        '<button type="button" class="btn btn-primary"><strong> Data Processing </strong></button>'
      ),
      tabsetPanel(
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Removing Missing Values</button>'
          ),
          
          sidebarLayout(
            sidebarPanel(
              HTML(
                '<h4 style="text-align: left; padding-left: 25%;"><strong>Variable Preprocessing:</strong></h4>'
              ),
              
              
            ),
            mainPanel(
              checkboxInput(
                inputId = "HEALTHCARE_free_Transform",
                label = "Transform NA in HEALTHCARE_COST to zero if HEALTHCARE_BASIS is free:",
                value = TRUE
              ),
            )),
          br(),
          HTML(
            '<h2 style="text-align: left; padding-left: 25%;"><strong>Data Cleaning:</strong></h2>'
          ),
          sidebarLayout(
            sidebarPanel(
              sliderInput(
                inputId = "VarThreshold",
                label = "Threshold of variable missingness",
                min = 1,
                max = 100,
                value = 29,
                post = "%"
              ),
              br(),
              br(),
              sliderInput(
                inputId = "ObsThreshold",
                label = "Threshold of observations missingness",
                min = 1,
                max = 100,
                value = 51,
                post = "%"
              ),
              br(),
              br(),
              textOutput("selected_result"),
              br(),
              br(),
              br(),
              width = 4
            ),
            mainPanel(sidebarMenu(
              HTML(
                '<h4 style="text-align: left; padding-left: 10%;"><strong>Cleaned Data Glimpse:</strong></h4>'
              ),
              withSpinner(verbatimTextOutput("glimpse_processed", placeholder = TRUE)),
              HTML(
                '<h4 style="text-align: left; padding-left: 10%;"><strong>Cleaned Data Summary:</strong></h4>'
              ),
              withSpinner(verbatimTextOutput("summary_processed", placeholder = TRUE))
            ))
          )
        ),
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Investigating Missing Values</button>'
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 1%;"><strong>Investigation for Cleaned Data:</strong></h2>'
          ),
          HTML(
            '<h4 style="text-align: left; padding-left: 5%;"><strong>Remove any variables that have no missing values: </strong></h4>'
          ),
          withSpinner(
          verbatimTextOutput("glimpse_missing_variables", placeholder = TRUE)),
          #textOutput("selected_fruit"),
          br(),
          HTML(
            '<h4 style="text-align: left; padding-left: 5%;"><strong>Variables having missing values in Cleaned Data:</strong></h4>'
          ),
          textOutput("selected_result_miss_vars"),
          br(),
          HTML(
            '<h4 style="text-align: left; padding-left: 5%;"><strong>Visualising the correlation structure of the binary missingness:</strong></h4>'
          ),
          sidebarLayout(sidebarPanel(
            selectInput(
              inputId = "Order_cor_rec_inves",
              label = "Select an order: ",
              choices = list(
                "none" = FALSE,
                "OLO" = "OLO",
                "GW" = "GW",
                "HC" = "HC"
              ),
              selected = "OLO"
            ),
            width = 3
          ),
          mainPanel(plotOutput(outputId = "cor_missing"))),
          HTML(
            '<h2 style="text-align: left; padding-left: 1%;"><strong>Predicting the Missingness:</strong></h2>'
          ),
          sidebarLayout(sidebarPanel(
            br(),
            br(),
            HTML(
              '<h5 style="text-align: left; padding-left: 1%;"><strong>This selection widget controls both plots</strong></h5>'
            ),
            br(),
            selectInput(
            inputId = "tree_variable_sel",
            label = "Select a variable for observing: ",
            choices = c("DEATH_RATE"),
            selected = "DEATH_RATE"
          )),
          mainPanel(HTML(
            '<h3 style="text-align: left; padding-left: 2%;"><strong>Tree for Raw Data:</strong></h3>'
          ),
          plotOutput(outputId = "Tree_raw"),
          #HTML(
          #  '<h3 style="text-align: left; padding-left: 2%;"><strong>Tree for Cleaned Data:</strong></h3>'
          #),
          #plotOutput(outputId = "Tree_rec")
          )
          ),
          
        ),
        #tabPanel(
        #  HTML(
        #    '<button type="button" class="btn btn-primary">Do not look at it: Table for Train & Test</button>'
        #  ),
        #  HTML(
        #    '<h2 style="text-align: left; padding-left: 10%;"><strong>Cleaned Data Table (Train):</strong></h2>'
        #  ),
        #  DT::dataTableOutput(outputId = "Cleaned_Data_Table_train"),
        #  br(),
        #  HTML(
        #    '<h2 style="text-align: left; padding-left: 10%;"><strong>Cleaned Data Table (Test):</strong></h2>'
        #  ),
        #  DT::dataTableOutput(outputId = "Cleaned_Data_Table_test"),
        #  style = "color:black; background-color: white;"
        #),
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Imputation Missing Values</button>'
          ),
          HTML(
            '<h2 style="text-align: left; padding-left: 1%;"><strong>Imputation for Cleaned Data:</strong></h2>'
          ),
          HTML(
            '<h4 style="text-align: left; padding-left: 3%;"><strong>1. Imputation Method Selection:</strong></h4>'
          ),
          selectInput(
            inputId = "ImpMethod",
            label = "Imputation method",
            choices = c("KNN", "Mean", "Median"),  #, "Partial Del"
            selected = "KNN"
          ),
          sliderInput(
            inputId = "KNN_Neighbors",
            label = "KNN Neighbors selection (this selection is avaliable only when KNN is selected for Imputation Method):",
            min = 1,
            max = 10,
            value = 10
          ),
          br(),
          HTML(
            '<h4 style="text-align: left; padding-left: 3%;"><strong>2. Imputed Data Checking (any missing values):</strong></h4>'
          ),
          withSpinner(plotOutput(outputId = "Missing")),
          #plotOutput(outputId = "Missing_test"),
          br(),
          HTML(
            '<h4 style="text-align: left; padding-left: 3%;"><strong>3. Imputed Data Preview by Observation Types:</strong></h4>'
          ),
          HTML(
            '<h5 style="text-align: center; padding-left: 3%;"><strong>For Training Data:</strong></h5>'
          ),
          withSpinner(
          dataTableOutput("Imputed_Data_train")),
          HTML(
            '<h5 style="text-align: center; padding-left: 3%;"><strong>For Testing Data:</strong></h5>'
          ),
          withSpinner(
          dataTableOutput("Imputed_Data_test"))
        ),
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Lower Dimensional Outliers</button>'
          ),
          HTML(
            '<h4 style="text-align: left; padding-left: 1%;"><strong>VAX_RATE OUTLIERS:</strong></h4>'
          ),
          checkboxInput(
            inputId = "VAX_RATE_Transform",
            label = "Transform the value of 15 in Variable VAX_RATE to NA:",
            value = TRUE
          ),
          br(),
          HTML(
            '<h1 style="text-align: left; padding-left: 1%;"><strong>Histogram:</strong></h1>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "hist_outlier_variables1",
                label = "Show variables:",
                choices = c(""),
                multiple = FALSE,
                selected = c("VAX_RATE")
              ),
              sliderInput(
                inputId = "hist_outlier_bins",
                label = "Number of bins:",
                min = 5,
                max = 30,
                value = 15
              ),
              width = 3
            ),
            mainPanel(
              withSpinner(
                plotOutput(outputId = "hist_outliers"),
              )
            )
          ),
          HTML(
            '<h1 style="text-align: left; padding-left: 1%;"><strong>Boxplot:</strong></h1>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Boxplot_outlier_variables_",
                label = "Show variables:",
                choices = c(""),
                multiple = FALSE,
                selected = c("VAX_RATE")
              ),
              sliderInput(
                inputId = "Boxplot_outlier_slider",
                label = "Number coef:",
                min = 1.5,
                max = 3,
                value = 1.5
              ),
              width = 3
            ),
            mainPanel(
              withSpinner(
                plotOutput(outputId = "boxplot_outliers"),
                )
              )
          ),
          HTML(
            '<h1 style="text-align: left; padding-left: 3%;"><strong>Bagplots:</strong></h1>'
          ),
          sidebarLayout(
            sidebarPanel(
              selectizeInput(
                inputId = "Bagplot_outlier_variables_",
                label = "Show variables:",
                choices = c(""),
                multiple = FALSE,
                selected = c("VAX_RATE")
              ),
              numericInput(
                inputId = "Bag_factor",
                label = "Bag factor:",
                value = 3,
                min = 2,
                max = 6,
                step = 1
              ),
              width = 3
            ),
            mainPanel(
                plotOutput(outputId = "bagplot_outliers"),
                tableOutput("bag_outliers_table")
               
            )
          )
          
        ),
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Model-Based Outliers Detection</button>'
          ),
          br(),
          HTML(
            '<h1 style="text-align: left; padding-left: 3%;"><strong>Mahalanbis Distance:</strong></h1>'
          ),
          sidebarLayout(
            sidebarPanel(
              HTML(
                '<h5 style="text-align: left; padding-left: 3%;"><strong>Note: outlier transformaiton is yet selected. </strong></h5>'
              ),
              width = 3), 
            mainPanel(plotOutput("manh_outlier_plot"))),
          
          HTML(
            '<h1 style="text-align: left; padding-left: 3%;"><strong>Cook Distance:</strong></h1>'
          ),
          sidebarLayout(sidebarPanel(sliderInput(
            inputId = "cook_threshold",
            label = "Select threshold (the default threshold (0.012) is 4 times the mean cook's distance):",
            value = 0.012,
            min = 0.001,
            max = 1,
            step = 0.001
          ),
          width = 3),mainPanel(plotOutput("cook_outlier_plot"))),
          
          
          HTML(
            '<h1 style="text-align: left; padding-left: 3%;"><strong>Local Outlier Factors:</strong></h1>'
          ),
          sidebarLayout(sidebarPanel(sliderInput(
            inputId = "olf_threshold",
            label = "Select threshold:",
            value = 2,
            min = 1,
            max = 5,
            step = 0.5
          ),
          sliderInput(
            inputId = "olf_minpoints",
            label = "Select minponits:",
            value = 4,
            min = 3,
            max = 10,
            step = 1
          ),
          width = 3), mainPanel(plotOutput("local_outlier_plot"))),
          
          
          HTML(
            '<h1 style="text-align: left; padding-left: 3%;"><strong>Isolation Forest:</strong></h1>'
          ),
          sidebarLayout(sidebarPanel(sliderInput(
            inputId = "iso_threshold",
            label = "Select threshold:",
            value = 0.5,
            min = 0,
            max = 1,
            step = 0.05
          ),
          width = 3), mainPanel(plotOutput("Isolation_Forest"))),
          HTML(
            '<h1 style="text-align: left; padding-left: 3%;"><strong>SVM:</strong></h1>'
          ),
          sidebarLayout(sidebarPanel(sliderInput(
            inputId = "svm_nu",
            label = "Select nu:",
            value = 0.02,
            min = 0,
            max = 0.02,
            step = 0.005
          ),
          width = 3), mainPanel(tableOutput("SVM_table")))
          
        ),
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary">Outliers Transformation</button>'
          ),
          
          HTML(
            '<h2 style="text-align: left; padding-left: 1%;"><strong>Two Methods for Outliers Transformation:</strong></h2>'
          ),
          sidebarLayout(sidebarPanel(
            br(),
            br(),
            br(),
          selectizeInput(
            inputId = "Method_Selection",
            label = "Method Selection:",
            choices = c("Yeo_Johnson", "Box_Cox", "No_Transformation"),
            multiple = FALSE,
            selected = c("No_Transformation")
          ),
          checkboxInput(
            inputId = "transform_outcome",
            label = "Transformation for outcome variable (DEATH_RATE): ",
            value = FALSE
          ),
          selectizeInput(
            inputId = "Transform_var",
            label = "Show variables:",
            choices = c(""),
            multiple = FALSE,
            selected = c("GDP")
          ), width = 3),
          mainPanel(
          plotOutput(outputId = "before_johnson"),
          plotOutput(outputId = "after_johnson"))
          ),
          br(),
          HTML(
            '<h3 style="text-align: left; padding-left: 1%;"><strong>Dataset with Outliers Transformed:</strong></h3>'
          ),
          dataTableOutput("YeoJtable")
        ),
        #tabPanel(
        #  HTML(
        #    '<button type="button" class="btn btn-primary">Model-Based Outlier Detection</button>'
        #  ),
        #  HTML(
        #    '<h2 style="text-align: left; padding-left: 1%;"><strong>Yeo-Johnson Based Detection:</strong></h2>'
        #  ),
        #  HTML(
        #    '<h3 style="text-align: left; padding-left: 1%;"><strong>Mahalanobis Distance</strong></h3>'
        #  ),
        #  selectizeInput(
        #    inputId = "Transform_var1",
        #    label = "Show variables:",
        #    choices = c(""),
        #    multiple = FALSE,
        #    selected = c("DOCS")
        #  ),
        #  plotOutput(outputId = "Mahalan")
        #)
      )
    ),

    
    #fourth panel is for Model Training
    tabPanel(
      HTML(
        '<button type="button" class="btn btn-primary"><strong>Model Training</strong></button>'
      ),
      
      tabsetPanel(
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary"><strong>Model Training</strong></button>'
          ),
          fluidRow(
            column(3, 
                   br(),
                   HTML(
                     '<h4 style="text-align: left; padding-left: 3%;"><strong>1. Check ThresholdSetting:</strong></h4>'
                   ),
                   sliderInput(
              inputId = "VarThreshold_2",
              label = "Threshold of variable missingness",
              min = 1,
              max = 100,
              value = 29,
              post = "%"
            ),
            br(),
            br(),
            sliderInput(
              inputId = "ObsThreshold_2",
              label = "Threshold of observations missingness",
              min = 1,
              max = 100,
              value = 51,
              post = "%"
            )), 
            column(3,
                   br(),
                   HTML(
                     '<h4 style="text-align: left; padding-left: 3%;"><strong>2. Check Imputation Method:</strong></h4>'
                   ), 
                   selectInput(
                     inputId = "ImpMethod2",
                     label = "Imputation method",
                     choices = c("KNN", "Mean", "Median"),#"Partial Del"
                     selected = "KNN"
                   ),
                   br(),
                   br(),
                   HTML(
                     '<h4 style="text-align: left; padding-left: 3%;"><strong>3. Choose Center and Scale:</strong></h4>'
                   ), 
                   checkboxInput(
                     inputId = "center_final",
                     label = "Center",
                     value = FALSE
                   ),
                   checkboxInput(
                     inputId = "scale_final",
                     label = "Scale",
                     value = FALSE
                   ),), 
            column(3,
                   br(),
                   HTML(
                     '<h4 style="text-align: left; padding-left: 3%;"><strong>4. Check Outlier Transformation:</strong></h4>'
                   ),
                   selectizeInput(
                     inputId = "Method_Selection_2",
                     label = "Method Selection:",
                     choices = c("Yeo_Johnson", "Box_Cox", "No_Transformation"),
                     multiple = FALSE,
                     selected = c("No_Transformation")
                   ),
                   br(),
                   br(),
                   HTML(
                     '<h5 style="text-align: left; padding-left: 3%;"><strong>Consideration for outcome:</strong></h5>'
                   ),
                   checkboxInput(
                     inputId = "transform_outcome_2",
                     label = "Transformation for outcome variable (DEATH_RATE): ",
                     value = FALSE
                   )), 
            column(3, 
                   br(),
                   br(),
                   br(),
                   br(),
                   HTML(
                     '<h4 style="text-align: left; padding-left: 3%;"><strong>5. Model Training:</strong></h4>'
                   ),
                   actionButton(
                     inputId = "Go",
                     label = "Train",
                     icon = icon("play")
                   ))
          ),
          br(),
          br(),
          HTML(
            '<h4 style="text-align: left; padding-left: 3%;"><strong>6. Model Performance</strong></h4>'
          ),
          withSpinner(verbatimTextOutput("Summary_Model", placeholder = TRUE)),
      
          br(),
          br(),
          HTML(
            '<h4 style="text-align: left; padding-left: 3%;"><strong>Training DataSet Overview: </strong></h4>'
          ),
          actionButton("show_table", "Show/Hide Table"),
          withSpinner(
            verbatimTextOutput("Summary_Imputed_train", placeholder = TRUE),
          ),
          
        ),
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary"><strong>Prediction</strong></button>'
          ),
          br(),
          HTML(
            '<h4 style="text-align: left; padding-left: 3%;"><strong>1. Make Predictions</strong></h4>'
          ),
          actionButton(
            inputId = "Go_Prediction",
            label = "Predict",
            icon = icon("play")
          ),
          br(),
          br(),
          HTML(
            '<h4 style="text-align: left; padding-left: 3%;"><strong>2. Prediction Performace</strong></h4>'
          ),
          HTML(
            '<h5 style="text-align: left; padding-left: 5%;"><strong>2.1 Test RMSE:</strong></h5>'
          ),
          withSpinner(verbatimTextOutput("RMSE_Model_test", placeholder = TRUE)),
          HTML(
            '<h5 style="text-align: left; padding-left: 5%;"><strong>2.2 Summary of Prediction:</strong></h5>'
          ),
          withSpinner(verbatimTextOutput("Summary_Model_test", placeholder = TRUE)),
          HTML(
            '<h4 style="text-align: left; padding-left: 3%;"><strong>Testing DataSet Overview: </strong></h4>'
          ),
          actionButton("show_test_table", "Show/Hide Table"),
          withSpinner(
            verbatimTextOutput("Summary_Imputed_test", placeholder = TRUE),
          )
          
          
        ),
        tabPanel(
          HTML(
            '<button type="button" class="btn btn-primary"><strong>Residuals Plots</strong></button>'
          ),
          br(),
          HTML(
            '<h4 style="text-align: left; padding-left: 3%;"><strong>Residual Plots:</strong></h4>'
          ),
          sliderInput(
            inputId = "Residual_outlier_slider",
            label = "Number coef:",
            min = 1.5,
            max = 3,
            value = 1.5
          ),
          HTML(
            '<h4 style="text-align: left; padding-left: 3%;"><strong>Residual Plots for training and test:</strong></h4>'
          ),
          plotOutput(outputId = "both_residual_boxplot"),
          HTML(
            '<h4 style="text-align: left; padding-left: 3%;"><strong>Residual Plots for training:</strong></h4>'
          ),
          plotOutput(outputId = "train_residual_boxplot"),
          HTML(
            '<h4 style="text-align: left; padding-left: 3%;"><strong>Residual Plots for testing:</strong></h4>'
          ),
          plotOutput(outputId = "test_residual_boxplot"),
          #withSpinner(verbatimTextOutput("Train_residuals", placeholder = TRUE))
          
          
        )
      )
    )
  )
  
  
  
)




#it is used to generate a loading spinner while the plot is being generated.
#withSpinner(
#  plotOutput("distplot")
#)