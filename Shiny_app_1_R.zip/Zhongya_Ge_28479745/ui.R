# Define UI for app
ui <- fluidPage(
  # App title
  theme = shinytheme("yeti"),
  titlePanel(HTML('<h1>Assignment 1 - Zhongya Ge</h1>')),


    tabsetPanel(
      tabPanel(HTML('<button type="button" class="btn btn-primary">OVERVIEW</button>'), 
               tabsetPanel(
                 tabPanel(HTML('<button type="button" class="btn btn-primary">Glimpse of Raw Data</button>'),
                          verbatimTextOutput("glimpse_raw", placeholder = TRUE)),
                 tabPanel(HTML('<button type="button" class="btn btn-primary">Glimpse</button>'),
                          verbatimTextOutput("glimpse", placeholder = TRUE)),
                 tabPanel(HTML('<button type="button" class="btn btn-primary">Summary</button>'),
                          verbatimTextOutput("summary", placeholder = TRUE)),
                 tabPanel(HTML('<button type="button" class="btn btn-primary">Summary Table</button>'),
                          uiOutput("summary_table", placeholder = TRUE))
               )),
      tabPanel(HTML('<button type="button" class="btn btn-primary">DATATABLE</button>'),
               br(),
               p("Explore ",
                 span("all dataset", style = "color:blue"),":"),
               DT::dataTableOutput(outputId = "Ass1Data")
      ),
      
      tabPanel(HTML('<button type="button" class="btn btn-primary">PLOT</button>'),
               tabsetPanel(
                 tabPanel(HTML('<button type="button" class="btn btn-primary">Vis_miss</button>'),
                          br(),
                          sidebarLayout(
                            sidebarPanel(
                              selectizeInput(inputId = "VariablesD", label = "Show variables:", choices = Vis_miss_choices, multiple = TRUE, selected = Vis_miss_choices, width = "100%"),
                              checkboxInput(inputId = "select_all_vars_vis", label = "Show All Variables", value = TRUE),
                              dateRangeInput("Date_range_vis", 
                                             "Put dates between 2019-01-12 and 2025-09-19",
                                             start = as.Date("2019-01-12"), # set default start date
                                             end = as.Date("2025-09-19"),   # set default end date
                                             min = as.Date("2019-01-12"),   # set minimum date
                                             max = as.Date("2025-09-19")    # set maximum date
                                             ),
                              width = 3,
                              style = "height: 850px; overflow-y: visible;"
                            ),
                            
                            mainPanel(
                              plotOutput(outputId = "vis_dat", width = "100%", height = "47%"),
                              plotOutput(outputId = "vis_miss", width = "100%", height = "47%"),
                              checkboxInput(inputId = "cluster", label = "Cluster missingness", value = FALSE),
                              width = 8,
                              style = "height: 850px;  overflow-y: visible; border: 0.5px solid grey;"
                            )
                          ),
                          p("Applies to all types of data (incl. IDs etc), does expand to ",
                            span("show many variables at once", style = "color:blue"),"but downsampling of observations might be required.")
                 ),
                 tabPanel(HTML('<button type="button" class="btn btn-primary">BoxPlot</button>'),
                          br(),
                          sidebarLayout(
                            sidebarPanel(
                              br(),
                              selectizeInput(inputId = "VariablesE", label = "Show variables:", choices = Box_plot_choices, multiple = TRUE, selected = c("sensor5",	"sensor6", "sensor14", "sensor18", "sensor23", "sensor26", "sensor29")),
                              numericInput(inputId = "boxplot_IQR", label = "IQR selection (from 0 to 4):", value = 1.5, min = 0, max = 4, step = 0.1),
                              checkboxInput(inputId = "center_Box", label = "Center", value = TRUE),
                              checkboxInput(inputId = "scale_Box", label = "Scale", value = TRUE),
                              width = 3,
                              style = "height: 660px; overflow-y: visible;"
                            ),
                            
                            mainPanel(
                              plotOutput(outputId = "Boxplot", width = "100%", height = "100%"),
                              uiOutput(outputId = "Boxplotresult"),
                              width = 8,
                              style = "height: 620px;  overflow-y: visible; border: 0.5px solid grey; "
                            )
                          )
                          
                 ),
                 tabPanel(HTML('<button type="button" class="btn btn-primary">Rising Value Chart</button>'),
                          br(),
                          sidebarLayout(
                            sidebarPanel(
                              br(),
                              selectizeInput(inputId = "VariablesF", label = "Show variables (at least 2 selections):", choices = Rising_value_choices, multiple = TRUE, selected = c("sensor5",	"sensor6", "sensor9", "sensor14", "sensor18", "sensor23", "sensor26", "sensor29")),
                              checkboxInput(inputId = "center_RV", label = "Center", value = FALSE),
                              checkboxInput(inputId = "scale_RV", label = "Scale", value = FALSE),
                              width = 3,
                              style = "height: 620px; overflow-y: visible;"
                            ),
                            
                            mainPanel(
                              plotOutput(outputId = "rising_value_chart", width = "100%", height = "100%"),
                              width = 8,
                              style = "height: 620px;  overflow-y: visible; border: 0.5px solid grey; "
                            )
                          ),
                          p("Applies to ",
                            span("numeric data only", style = "color:blue"),", does expand to show many variables at once if centring and scaling employed.")
                          
                 ),
                 tabPanel(HTML('<button type="button" class="btn btn-primary">Histogram</button>'),
                          br(),
                          
                          div(
                            style = "display: flex; flex-direction: row; justify-content: space-between; align-items: center;",
                            br(),
                            selectizeInput(inputId = "VariablesG", label = "Show variables:", choices = Histo_choices, multiple = FALSE, selected = c("sensor5")),
                            sliderInput(inputId = "hist_bins", label = "Number of bins:",min = 10,max = 60,value = 50),
                            br()
                          ),
                          plotlyOutput(outputId = "histogram_chart", width = "100%", height = "100%"),
                          p(span("Numeric data only", style = "color:blue"),", does not scale to show many variables at once.")
                 ),
                 tabPanel(HTML('<button type="button" class="btn btn-primary">Matplot</button>'),
                          sidebarLayout(
                            sidebarPanel(
                          selectizeInput(inputId = "VariablesH", label = "Show variables:", choices = Homo_choices, multiple = TRUE, selected = Homo_choices),
                          br(),
                          br(),
                          checkboxInput(inputId = "center_Homo", label = "Center", value = TRUE),
                          checkboxInput(inputId = "scale_Homo", label = "Scale", value = TRUE),
                          checkboxInput(inputId = "select_all_vars_matplot", label = "Show All Variables", value = TRUE),
                            ),
                          mainPanel(
                          plotOutput(outputId = "homogeneity_chart"),
                          
                          p("Applies to ",
                            span(" normally numeric data only", style = "color:blue"),", does exapand to ",
                            span("show many variables at once", style = "color:blue"), " if centring and scaling employed."))
                          
                 )),
                 tabPanel(HTML('<button type="button" class="btn btn-primary">Mosaic</button>'),
                   br(),
                   div(
                     style = "display: flex; flex-direction: row; justify-content: space-between; align-items: center;",
                     selectizeInput(inputId = "VariablesA", label = "Show variables:", choices = mosaic_choices, multiple = TRUE, selected = c("Operator","Year"))),
                   plotOutput(outputId = "Mosaic"),
                   br(),
                   br(),
                   p("Mosaic Chart is for categorical variables with low cardinality. In general, it is recommended to limit the number of variables in a mosaic chart to",
                     span("two or three variables", style = "color:blue"),".")
                 ),
                 tabPanel(HTML('<button type="button" class="btn btn-primary">Correlation</button>'),
                          br(),
                          
                          sidebarLayout(
                            sidebarPanel(
                              br(),
                              selectizeInput(inputId = "VariablesC", label = "Show variables:", choices = cor_choices, multiple = TRUE, selected = cor_choices),
                              checkboxInput(inputId = "select_all_vars_cor", label = "Show All Variables", value = TRUE),
                              selectInput(inputId = "cor_method_sel", label = "Select a correlation method:", choices = c("pearson", "kendall", "spearman")),
                              selectInput(inputId = "Order_cor", label = "Select an order: ", choices = list("none" = FALSE, "OLO"="OLO", "GW"="GW","HC"="HC"), selected = "HC"),
                              checkboxInput(inputId = "abs", label = "ABS", value = TRUE),
                              width = 3,
                              style = "height: 620px; overflow-y: visible;"
                            ),
                            
                            mainPanel(
                              plotOutput(outputId = "AutoCorr", width = "100%", height = "100%"),
                              width = 8,
                              style = "height: 620px;  overflow-y: visible; border: 0.5px solid grey; "
                            )
                          ),
                          p(span("Numeric data only", style = "color:blue"),", does scale to show many variables at once."),
                 ),
                 tabPanel(HTML('<button type="button" class="btn btn-primary">GGpairs</button>'),
                          br(),
                          sidebarLayout(
                            sidebarPanel(
                             
                              numericInput(inputId = "Portion_num", label = "Portion Split:", value = 0.7, min = 0.00001, max = 1),
                              numericInput(inputId = "top_display", label = "Top n to display:", value = 5, min = 1, max = 40),
                              selectInput(inputId = "method_sel", label = "Select a method for Variable Importance calculation:", choices = c("glm", "rf")),
                              br(),
                              br(),
                              br(),
                              br(),
                              br(),
                              br(),
                              br(),
                              selectizeInput(inputId = "VariablesB", label = "Show variables:", choices = ggpair_sel_choices, multiple = TRUE, selected = c("sensor5","sensor6","sensor14","sensor18","sensor23","sensor26")),
                              selectInput(inputId = "color_sel_ggpairs", label = "Select a Variable for plotting color", choices = ggpair_choices, selected = c("Operator")),
                              p("Note: To plot color, make sure this color variable has been selected for the plotting GGpair chart!"),
                              width = 3,
                              style = "height: 850px; overflow-y: visible;"
                            ),
                            
                            mainPanel(
                              plotOutput(outputId = "Variable_Impor", width = "100%", height = "50%"),
                             
                              plotOutput(outputId = "Ggpairs", width = "100%", height = "50%"),
                              width = 8,
                              style = "height: 850px;  overflow-y: visible; border: 0.5px solid grey;"
                            )
                          ),
                          p("Applies to",
                            span("both numeric & categorical variables", style = "color:blue"),"but does not scale with many variables."),
                 ),
                 #tabPanel(HTML('<button type="button" class="btn btn-primary">PCA</button>'),
                 #         br(),
                 #         
                 #         div(
                 #           style = "display: flex; flex-direction: row; justify-content: space-between; align-items: center;",
                 #           
                 #           selectizeInput(inputId = "VariablesI", label = "Show variables:", choices = PCA_choices, multiple = TRUE, selected = c("sensor1", "sensor2", "sensor3"), width = "40%"),
                 #           br(),
                 #           br(),
                 #           checkboxInput(inputId = "center_PCA", label = "Center", value = TRUE),
                 #           checkboxInput(inputId = "scale_PCA", label = "Scale", value = TRUE)
                 #           
                 #         ),
                 #         
                 #         plotOutput(outputId = "PCA_chart"),
                 #         p("Principal Component analysis is a ",
                 #           span("purely numeric dimensional reduction", style = "color:blue"),".")
                 #         )
                 )
               )
      )
  )