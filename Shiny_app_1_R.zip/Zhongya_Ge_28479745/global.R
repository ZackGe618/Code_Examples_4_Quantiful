#install.packages("shiny")
#install.packages("mosaic")
#devtools::install_github("haleyjeppson/ggmosaic")
#install.packages("caret")
#install.packages("ggplot2")
#install.packages("GGally")
#install.packages("dplyr")
#install.packages("visdat")
#install.packages("DT")
#install.packages("RColorBrewer")
#install.packages("plotly")
#install.packages("htmlTable")
#install.packages("expss")
#install.packages("lubridate")
#install.packages("bslib")
#install.packages("shinythemes")
#install.packages("vcd")
#install.packages("summarytools")
#install.packages("seriation")
#install.packages("corrgram")
library(shiny)
library(mosaic)
library(ggmosaic)
library(ggplot2)
library(caret)
library(GGally)
library(dplyr)
library(visdat)
library(DT)
library(RColorBrewer)
library(plotly)
library(htmlTable)
library(expss)
library(lubridate)
library(bslib)
library(shinythemes)
library(vcd)
library(summarytools)
library(seriation)
library(corrgram)



#load csv file
data = read.csv("Ass1Data.csv", header = TRUE, stringsAsFactors = TRUE)

#convert data in to data Frame
data_raw <- data %>% 
  as.data.frame()

#convert data in to data Frame
data_df <- data %>% 
  as.data.frame()

#change Date variable into date format
data_df <- data_df %>% 
  mutate(Date = as.Date(Date))

#extract month and year info from Date variable, and make it in order
data_df <- data_df %>% 
  mutate(Year = factor(year(Date), order = TRUE, levels = 2019:2025),
         Month = factor(month(Date), order = TRUE, levels = 1:12))
  
#convert Priority, Price, Speed, Duration, Temp in to order
data_df <- data_df %>% 
  mutate(Priority = factor(Priority, order = TRUE, levels = c("Low", "Medium", "High")),
         Price = factor(Price, order = TRUE, levels = c("Cheap", "Fair", "Expensive")),
         Speed = factor(Speed, order = TRUE, levels = c("Slow", "Medium", "Fast")),
         Duration = factor(Duration, order = TRUE, levels = c("Short", "Long", "Very Long")),
         Temp = factor(Temp, order = TRUE, levels = c("Cold", "Warm", "Hot")))
  
#convert ID to character type
data_df$ID = as.character(data_df$ID)

data_df <- data_df %>% select(Year, everything())
data_df <- data_df %>% select(Month, everything())

#specify selection content for each chart
#   for mosaic
mosaic_choices <- colnames(select(data_df, -c(Y, ID, Date, paste0("sensor", 1:30))))
#   for ggpair
ggpair_sel_choices <- colnames(select(data_df, -c(ID, Date)))
ggpair_choices <- colnames(select(data_df, -c(Y, ID, Date, paste0("sensor", 1:30))))
#   for correlation
cor_choices <- colnames(select(data_df, c(Y, paste0("sensor", 1:30))))
#   for Vis_miss
Vis_miss_choices <- colnames(data_df)
#   for BoxPlot
Box_plot_choices <- colnames(select(data_df, c(Y, paste0("sensor", 1:30))))
#   for Rising Value Chart
Rising_value_choices <- colnames(select(data_df, c(Y, paste0("sensor", 1:30))))
#   for Histogram
Histo_choices <- colnames(select(data_df, c(Y, paste0("sensor", 1:30))))
#   for Homogeneity
Homo_choices <- colnames(select(data_df, c(Y, paste0("sensor", 1:30))))
#   for PCA
PCA_choices <- colnames(select(data_df, c(Y, paste0("sensor", 1:30))))
  
#shinyApp(ui, server)

