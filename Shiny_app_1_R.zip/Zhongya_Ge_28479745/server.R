
# Define server logic
server <- function(input, output, session) {
  
  # Summary output
  output$summary <- renderPrint({
    summary(data_df)
  })
  
  # Glimpse output
  output$glimpse_raw <- renderPrint({
    #disselect ID column 
    tibble::glimpse(data_raw)
  })
  
  # Glimpse output
  output$glimpse <- renderPrint({
    #disselect ID column 
    tibble::glimpse(data_df)
  })
  
  output$summary_table <- renderUI({
    print(dfSummary(data_df), method = "render")
  })

  # Plot output of Mosaic
  output$Mosaic <- renderPlot({
    formula <- as.formula(paste("~",paste(input$VariablesA, collapse = " + ")))
    vcd::mosaic(formula, data = data_df, 
                main = "Mosaic Plot for Discrete Variable", shade = TRUE, legend = TRUE)
  })
  
  
  # Plot output of Variable Importance
  output$Variable_Impor <- renderPlot({
    req(data_df)
    #disselect ID and Date column 
    data_df_no_Vdate <- select(data_df, -c(Date, ID))
    set.seed(3)
    trainInd <- caret::createDataPartition(y = data_df_no_Vdate$Y, times = 1, p = input$Portion_num, list = FALSE)
    data_df_no_Vdate.train <- data_df_no_Vdate[trainInd,]
    modass1 <- caret::train(form = Y ~ ., data = data_df_no_Vdate.train, method = input$method_sel, na.action = na.omit)
    plot(caret::varImp(modass1), top = input$top_display, main = paste("Variable Importance Plot - Top", input$top_display))
  })
  
  
  
  # Plot output of ggpairs
  output$Ggpairs <- renderPlot({
    #disselect ID column 
    data_df <- subset(data_df, select = -c(ID))
    # select data based on input$VariableB 
    neededVars <- c(input$VariablesB, input$color_sel_ggpairs)
    data_df_VB <- data_df[, neededVars]
    # color selection based on input$color_sel_ggpairs
    color_sel = input$color_sel_ggpairs
    #plot ggpairs, note the selection input returns quoted result, but for color argument, it needs unquoted value
    GGally::ggpairs(data = data_df_VB,  
                    mapping = aes(colour = !!sym(input$color_sel_ggpairs)),  
                    title = paste("Pairs of Ass1Data colored by", color_sel),
                    progress = TRUE)
    })
  
  
  
  # Plot output of Corrgram
  output$AutoCorr <- renderPlot({
    
    # Update the input whenever select_all_vars is checked
    observeEvent(input$select_all_vars_cor, {
      if(input$select_all_vars_cor) {
        updateSelectInput(session, "VariablesC", choices = cor_choices, selected = cor_choices)
      } 
    })
    
    observeEvent(input$VariablesC, {
      if(length(input$VariablesC) != length(cor_choices)) {
        updateCheckboxInput(session, "select_all_vars_cor", value = FALSE)
      } 
    })
    
    #disselect ID column 
    data_df <- subset(data_df, select = -c(ID))
    # select data based on input$VariableC
    data_df_VC = subset(data_df, select = input$VariablesC)
    #disselect NA values 
    data_df_VC_noNA <- na.omit(data_df_VC)
    #Plot Correlation Chart
    corrgram::corrgram(data_df_VC_noNA, 
                       order = input$Order_cor, 
                       abs = input$abs, 
                       upper.panel = panel.cor,
                       cor.method = input$cor_method_sel, 
                       main = "Correlation Chart")
  })
  
  #Plot Missing data Visualization
  # Update the input whenever select_all_vars is checked
  observeEvent(input$select_all_vars_vis, {
    if(input$select_all_vars_vis) {
      updateSelectInput(session, "VariablesD", choices = Vis_miss_choices, selected = Vis_miss_choices)
    } 
  })
  
  observeEvent(input$VariablesD, {
    if(length(input$VariablesD) != length(Vis_miss_choices)) {
      updateCheckboxInput(session, "select_all_vars_vis", value = FALSE)
    } 
  })
  
  output$vis_dat <- renderPlot({
    # convert data into DataFrame
    data_df_4_vis = as.data.frame(data_df)
    
    # Select rows with date between two dates
    start_date <- as.Date(input$Date_range_vis[1])
    end_date <- as.Date(input$Date_range_vis[2])
    data_df_4_vis <- data_df_4_vis[data_df_4_vis$Date >= start_date & data_df_4_vis$Date <= end_date, ]
    
    # select data based on input$VariableD
    data_use_vis_dat = subset(data_df_4_vis, select = input$VariablesD)
    # plot Missing Value Chart by vis_dat
    vis_dat(data_use_vis_dat) +
      ggtitle("Missing Data for all variables by variable type")
  })
  
  #Plot Missing data Visualization
  output$vis_miss <- renderPlot({
    # convert data into DataFrame
    data_df_4_vis = as.data.frame(data_df)
    
    # Select rows with date between two dates
    start_date <- as.Date(input$Date_range_vis[1])
    end_date <- as.Date(input$Date_range_vis[2])
    data_df_4_vis <- data_df_4_vis[data_df_4_vis$Date >= start_date & data_df_4_vis$Date <= end_date, ]
    
    # select data based on input$VariableD
    data_use_vis_miss = subset(data_df_4_vis, select = input$VariablesD)
    # plot Missing Value Chart by vis_miss
    vis_miss(data_use_vis_miss, cluster = input$cluster) +
      labs(title = "Percentage of Missing Value")+
      theme(legend.position = "right")
  })
  
  #create data table
  output$Ass1Data <- DT::renderDataTable({
    # create data table
    DT::datatable(data = data_df, 
                  options = list(
                    paging = TRUE,
                    pageLength = 20,
                    pagingType = "full_numbers"
                    )
                  )
  })
  
  #Plot Boxplot
  output$Boxplot <- renderPlot({
    #disselect ID column 
    data_df <- subset(data_df, select = -c(ID))
    criterion <- input$boxplot_IQR
    cols <- input$VariablesE # choose the continuous columns
    numData <- scale(data_df[,cols], center = input$center_Box, scale = input$scale_Box) 
    car::Boxplot(numData, range = criterion, col = c("palegreen", "paleturquoise1", "palevioletred1", "rosybrown1", "khaki1", "plum2", "slategray1", "aliceblue"), main = "BoxPlot")
  
  })
  
  output$Boxplotresult <- renderPrint({
    #disselect ID column 
    data_df <- subset(data_df, select = -c(ID))
    criterion <- input$boxplot_IQR
    cols <- input$VariablesE # choose the continuous columns
    
    cat("Observations to be investigated (line number): ")
    for (col in cols) {
      numData <- scale(data_df[,col], center = input$center_Box, scale = input$scale_Box) 
      boxplot <- car::Boxplot(numData, range = criterion, col = "lightblue")
      a = col
      b= boxplot
      cat(a, ": ","\n", b, "\n", ";            ")
    }
    
  })
  
  #plot rising value chart
  output$rising_value_chart <- renderPlot({
    #disselect ID column 
    data_df <- subset(data_df, select = -c(ID))
    cols <- input$VariablesF
    d <- data_df[,cols]  # select the definitely-continuous columns
    for (col in 1:ncol(d)) {
      d[,col] <- d[order(d[,col]),col] #sort each column in ascending order
    }
    d <- scale(x = d, center = input$center_RV, scale = input$scale_RV)
    mypalette <- rainbow(ncol(d))
    matplot(x = seq(1, 100, length.out = nrow(d)), y = d, type = "l", xlab = "Percentile", ylab = "Values", lty = 1, lwd = 1, col = mypalette, main = "Rising value chart")
    legend(legend = colnames(d), x = "topleft", y = "top", lty = 1, lwd = 1, col = mypalette, ncol = round(ncol(d)^0.3))
  })
  
  #plot histogram chart
  output$histogram_chart <- renderPlotly({
    #disselect ID column 
    data_df <- subset(data_df, select = -c(ID))
    hist_var_selected = input$VariablesG
    p <- ggplot2::ggplot(data = data_df, mapping = aes(x = !!sym(hist_var_selected))) +
      geom_histogram(bins = input$hist_bins) +
      labs(title = paste("Histogram of ", hist_var_selected), xlab = paste("The range of", hist_var_selected))
    ggplotly(p)
  })
  
  #plot homogeneity chart  
  output$homogeneity_chart <- renderPlot({
    
    observeEvent(input$select_all_vars_matplot, {
      if(input$select_all_vars_matplot) {
        updateSelectInput(session, "VariablesH", choices = Homo_choices, selected = Homo_choices)
      } 
    })
    
    observeEvent(input$VariablesH, {
      if(length(input$VariablesH) != length(Homo_choices)) {
        updateCheckboxInput(session, "select_all_vars_matplot", value = FALSE)
      } 
    })
    
    #disselect ID column 
    data_df <- subset(data_df, select = -c(ID))
    # choose the numeric columns
    cols <- input$VariablesH
    data_use <- scale(data_df[,cols], center = input$center_Homo, scale = input$scale_Homo) 
    matplot(data_use, type = "l", col = rainbow(ncol(data_use)), xlab = "Observations in sequence", ylab = "Value", main = "Matplot") 
  })
  
  # Plot output of PCA chart
  #output$PCA_chart <- renderPlot({
  #  #disselect ID column 
  #  data_df <- subset(data_df, select = -c(ID))
  #  formula <- as.formula(paste("~", paste(input$VariablesI, collapse = "+")))
  #  pca <- prcomp(formula, data_df, center = input$center_PCA, scale. = input$scale_PCA)
  #  ggplot() +
  #    geom_point(mapping = aes(x = pca$x[,1], y = pca$x[,2])) + # plot only the first two principle components
  #    labs(title = "Scatter plot of first two principle components", x = "PC1", y = "PC2")
  #})
}